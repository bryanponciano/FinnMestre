<?php
/**
 * API: Excluir Transação
 */
require_once __DIR__ . '/api_auth.php';
require_once '../includes/functions.php';

$id = intval($_GET['id'] ?? 0);

if ($id <= 0) {
    echo json_encode(['sucesso' => false, 'erro' => 'ID inválido']);
    exit;
}

$resultado = excluirTransacao($id);

echo json_encode(['sucesso' => $resultado]);
