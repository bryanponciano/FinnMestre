﻿<?php
/**
 * API: Exportar Relatórios
 */
require_once '../includes/functions.php';

$formato = $_GET['formato'] ?? 'csv';
$dataInicio = $_GET['data_inicio'] ?? date('Y-m-01');
$dataFim = $_GET['data_fim'] ?? date('Y-m-t');
$tipo = $_GET['tipo'] ?? '';
$perfilFiltro = $_GET['perfil'] ?? 'atual';

// Determinar quais perfis usar no filtro
$todosPerfis = function_exists('listarPerfis') ? listarPerfis() : [];
$perfilAtual = function_exists('obterPerfilAtual') ? obterPerfilAtual() : null;
$perfilIdSessao = $_SESSION['perfil_id'] ?? null;

$perfisParaExportar = [];
if ($perfilFiltro === 'todos') {
    $perfisParaExportar = array_column($todosPerfis, 'id');
} elseif ($perfilFiltro === 'atual') {
    // Usar direto da sessão
    if ($perfilIdSessao) {
        $perfisParaExportar = [$perfilIdSessao];
    }
} elseif (is_numeric($perfilFiltro)) {
    $perfisParaExportar = [intval($perfilFiltro)];
}

$filtros = [
    'data_inicio' => $dataInicio,
    'data_fim' => $dataFim
];

// SEMPRE passar perfis explicitamente para garantir isolamento
if (!empty($perfisParaExportar)) {
    $filtros['perfil_ids'] = $perfisParaExportar;
} elseif ($perfilIdSessao) {
    // Fallback: usar perfil da sessão
    $filtros['perfil_ids'] = [$perfilIdSessao];
}

if ($tipo)
    $filtros['tipo'] = $tipo;

$transacoes = listarTransacoes($filtros);

if ($formato === 'csv') {
    // Exportar CSV
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename="FinnMestre_relatorio_' . date('Y-m-d') . '.csv"');

    $output = fopen('php://output', 'w');

    // BOM para UTF-8
    fprintf($output, chr(0xEF) . chr(0xBB) . chr(0xBF));

    // Cabeçalho
    fputcsv($output, ['Data', 'Descrição', 'Categoria', 'Conta', 'Tipo', 'Valor'], ';');

    // Dados
    foreach ($transacoes as $t) {
        fputcsv($output, [
            formatarData($t['data_transacao']),
            $t['descricao'],
            $t['categoria_nome'] ?? 'Sem categoria',
            $t['conta_nome'] ?? '-',
            ucfirst($t['tipo']),
            number_format($t['valor'], 2, ',', '.')
        ], ';');
    }

    // Totais
    $totalEntradas = array_sum(array_map(fn($t) => $t['tipo'] === 'entrada' ? $t['valor'] : 0, $transacoes));
    $totalSaidas = array_sum(array_map(fn($t) => $t['tipo'] === 'saida' ? $t['valor'] : 0, $transacoes));

    fputcsv($output, [], ';');
    fputcsv($output, ['', '', '', '', 'Total Entradas', number_format($totalEntradas, 2, ',', '.')], ';');
    fputcsv($output, ['', '', '', '', 'Total Saídas', number_format($totalSaidas, 2, ',', '.')], ';');
    fputcsv($output, ['', '', '', '', 'Balanço', number_format($totalEntradas - $totalSaidas, 2, ',', '.')], ';');

    fclose($output);
    exit;
}

// Formato HTML para impressão/PDF
header('Content-Type: text/html; charset=utf-8');
?>
<!DOCTYPE html>
<html lang="pt-BR">

<head>
    <meta charset="UTF-8">
    <title>Relatório FinnMestre -
        <?= date('d/m/Y') ?>
    </title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: Arial, sans-serif;
            font-size: 12px;
            padding: 20px;
        }

        h1 {
            font-size: 18px;
            margin-bottom: 5px;
            color: #10b981;
        }

        .periodo {
            color: #666;
            margin-bottom: 20px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }

        th,
        td {
            padding: 8px;
            border: 1px solid #ddd;
            text-align: left;
        }

        th {
            background: #f5f5f5;
            font-weight: bold;
        }

        .entrada {
            color: #10b981;
        }

        .saida {
            color: #ef4444;
        }

        .totais {
            margin-top: 20px;
        }

        .totais table {
            max-width: 300px;
            margin-left: auto;
        }

        .totais th {
            text-align: right;
        }

        @media print {
            body {
                padding: 0;
            }

            button {
                display: none;
            }
        }
    </style>
</head>

<body>
    <div style="text-align: right; margin-bottom: 20px;">
        <button onclick="window.print()">🖨️ Imprimir / Salvar PDF</button>
    </div>

    <h1>📊 Relatório Financeiro - FinnMestre</h1>
    <p class="periodo">Período:
        <?= formatarData($dataInicio) ?> até
        <?= formatarData($dataFim) ?>
    </p>

    <table>
        <thead>
            <tr>
                <th>Data</th>
                <th>Descrição</th>
                <th>Categoria</th>
                <th>Conta</th>
                <th>Tipo</th>
                <th style="text-align: right;">Valor</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($transacoes as $t): ?>
                <tr>
                    <td>
                        <?= formatarData($t['data_transacao']) ?>
                    </td>
                    <td>
                        <?= htmlspecialchars($t['descricao']) ?>
                    </td>
                    <td>
                        <?= htmlspecialchars($t['categoria_nome'] ?? '-') ?>
                    </td>
                    <td>
                        <?= htmlspecialchars($t['conta_nome'] ?? '-') ?>
                    </td>
                    <td class="<?= $t['tipo'] ?>">
                        <?= ucfirst($t['tipo']) ?>
                    </td>
                    <td style="text-align: right;" class="<?= $t['tipo'] ?>">
                        <?= formatarMoeda($t['valor']) ?>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>

    <?php
    $totalEntradas = array_sum(array_map(fn($t) => $t['tipo'] === 'entrada' ? $t['valor'] : 0, $transacoes));
    $totalSaidas = array_sum(array_map(fn($t) => $t['tipo'] === 'saida' ? $t['valor'] : 0, $transacoes));
    ?>

    <div class="totais">
        <table>
            <tr>
                <th>Total Entradas:</th>
                <td class="entrada"><strong>
                        <?= formatarMoeda($totalEntradas) ?>
                    </strong></td>
            </tr>
            <tr>
                <th>Total Saídas:</th>
                <td class="saida"><strong>
                        <?= formatarMoeda($totalSaidas) ?>
                    </strong></td>
            </tr>
            <tr>
                <th>Balanço:</th>
                <td class="<?= ($totalEntradas - $totalSaidas) >= 0 ? 'entrada' : 'saida' ?>">
                    <strong>
                        <?= formatarMoeda($totalEntradas - $totalSaidas) ?>
                    </strong>
                </td>
            </tr>
        </table>
    </div>

    <p style="margin-top: 30px; color: #999; font-size: 10px;">
        Gerado em
        <?= date('d/m/Y H:i') ?> por FinnMestre
    </p>
</body>

</html>