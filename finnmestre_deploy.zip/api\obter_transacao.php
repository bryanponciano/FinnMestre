<?php
/**
 * API: Obter Transação
 */
header('Content-Type: application/json');
require_once '../includes/functions.php';

$id = intval($_GET['id'] ?? 0);

if ($id <= 0) {
    echo json_encode(['sucesso' => false, 'erro' => 'ID inválido']);
    exit;
}

$transacao = obterTransacao($id);

if ($transacao) {
    echo json_encode(['sucesso' => true, 'transacao' => $transacao]);
} else {
    echo json_encode(['sucesso' => false, 'erro' => 'Transação não encontrada']);
}
