<?php
/**
 * API: Salvar Transação
 */
session_start();
header('Content-Type: application/json');

require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/functions.php';

// Verificar autenticação
if (!isset($_SESSION['usuario_logado']) || !$_SESSION['usuario_logado']) {
    echo json_encode(['sucesso' => false, 'erro' => 'Não autenticado']);
    exit;
}

$input = json_decode(file_get_contents('php://input'), true);

if (!$input) {
    echo json_encode(['sucesso' => false, 'erro' => 'Dados inválidos']);
    exit;
}

// Obter perfil atual
$perfilId = $_SESSION['perfil_id'] ?? null;

$dados = [
    'id' => $input['id'] ?? null,
    'perfil_id' => $perfilId,
    'descricao' => trim($input['descricao'] ?? ''),
    'valor' => floatval($input['valor'] ?? 0),
    'tipo' => $input['tipo'] ?? 'saida',
    'categoria_id' => $input['categoria_id'] ?: null,
    'conta_id' => $input['conta_id'] ?: null,
    'conta_destino_id' => $input['conta_destino_id'] ?: null,
    'data_transacao' => $input['data_transacao'] ?? date('Y-m-d'),
    'total_parcelas' => intval($input['total_parcelas'] ?? 1),
    'observacao' => trim($input['observacao'] ?? '')
];

if (empty($dados['descricao']) || $dados['valor'] <= 0) {
    echo json_encode(['sucesso' => false, 'erro' => 'Descrição e valor são obrigatórios']);
    exit;
}

try {
    $resultado = salvarTransacao($dados);
    echo json_encode(['sucesso' => $resultado, 'mensagem' => 'Transação salva com sucesso!']);
} catch (Exception $e) {
    echo json_encode(['sucesso' => false, 'erro' => 'Erro ao salvar: ' . $e->getMessage()]);
}
