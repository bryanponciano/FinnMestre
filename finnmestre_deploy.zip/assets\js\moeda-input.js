/**
 * =====================================================
 * FORMATADOR DE INPUT MONETÁRIO - PADRÃO BRASILEIRO
 * Formata valores em tempo real: 1.234,56
 * =====================================================
 */

/**
 * Inicializa a máscara monetária em um input
 * @param {HTMLInputElement} input - Elemento input a ser formatado
 * @param {Object} options - Opções de configuração
 */
function inicializarInputMonetario(input, options = {}) {
    const config = {
        separadorMilhares: options.separadorMilhares || '.',
        separadorDecimal: options.separadorDecimal || ',',
        casasDecimais: options.casasDecimais || 2,
        prefixo: options.prefixo || '',
        sufixo: options.sufixo || ''
    };

    // Armazena configuração no elemento
    input._configMoeda = config;

    // Event listeners
    input.addEventListener('input', handleInput);
    input.addEventListener('keydown', handleKeydown);
    input.addEventListener('paste', handlePaste);
    input.addEventListener('focus', handleFocus);
    input.addEventListener('blur', handleBlur);

    /**
     * Handler principal de input
     */
    function handleInput(e) {
        const posicaoCursor = input.selectionStart;
        const valorAntigo = input.value;
        const tamanhoAntigo = valorAntigo.length;

        // Remove tudo exceto números
        let apenasNumeros = input.value.replace(/\D/g, '');

        // Formata o valor
        const valorFormatado = formatarValorMonetario(apenasNumeros, config);

        // Atualiza o input
        input.value = valorFormatado;

        // Ajusta posição do cursor
        const tamanhoNovo = valorFormatado.length;
        const diferenca = tamanhoNovo - tamanhoAntigo;
        let novaPosicao = posicaoCursor + diferenca;

        // Garante que o cursor não fique em posição inválida
        novaPosicao = Math.max(config.prefixo.length, novaPosicao);
        novaPosicao = Math.min(valorFormatado.length - config.sufixo.length, novaPosicao);

        // Define a posição do cursor
        requestAnimationFrame(() => {
            input.setSelectionRange(novaPosicao, novaPosicao);
        });
    }

    /**
     * Previne teclas inválidas
     */
    function handleKeydown(e) {
        const teclasPermitidas = [
            'Backspace', 'Delete', 'Tab', 'Escape', 'Enter',
            'ArrowLeft', 'ArrowRight', 'ArrowUp', 'ArrowDown',
            'Home', 'End'
        ];

        // Permite teclas de controle
        if (teclasPermitidas.includes(e.key)) return;

        // Permite Ctrl+A, Ctrl+C, Ctrl+V, Ctrl+X
        if (e.ctrlKey || e.metaKey) return;

        // Bloqueia se não for número
        if (!/^\d$/.test(e.key)) {
            e.preventDefault();
        }
    }

    /**
     * Trata colagem de valores
     */
    function handlePaste(e) {
        e.preventDefault();
        const textoColar = (e.clipboardData || window.clipboardData).getData('text');

        // Remove tudo exceto números, vírgulas e pontos
        let valorLimpo = textoColar.replace(/[^\d.,]/g, '');

        // Se tiver vírgula como decimal (padrão BR), converte para ponto
        if (valorLimpo.includes(',')) {
            // Remove pontos de milhar e troca vírgula por ponto
            valorLimpo = valorLimpo.replace(/\./g, '').replace(',', '.');
        }

        // Converte para número e de volta para string
        const numero = parseFloat(valorLimpo);
        if (!isNaN(numero)) {
            // Multiplica por 100 para ter centavos e formata
            const centavos = Math.round(numero * Math.pow(10, config.casasDecimais)).toString();
            input.value = formatarValorMonetario(centavos, config);
        }
    }

    /**
     * Seleciona todo o conteúdo ao focar
     */
    function handleFocus(e) {
        requestAnimationFrame(() => {
            input.select();
        });
    }

    /**
     * Garante formatação ao sair do campo
     */
    function handleBlur(e) {
        if (input.value === '' || input.value === config.prefixo + config.sufixo) {
            input.value = formatarValorMonetario('0', config);
        }
    }
}

/**
 * Formata uma string de números para o padrão monetário
 * @param {string} numeros - String contendo apenas números
 * @param {Object} config - Configurações de formatação
 * @returns {string} Valor formatado
 */
function formatarValorMonetario(numeros, config) {
    // Garante que temos pelo menos os dígitos das casas decimais
    const minDigitos = config.casasDecimais + 1;
    numeros = numeros.padStart(minDigitos, '0');

    // Remove zeros à esquerda excessivos
    while (numeros.length > minDigitos && numeros[0] === '0') {
        numeros = numeros.substring(1);
    }

    // Separa parte inteira e decimal
    const posicaoDecimal = numeros.length - config.casasDecimais;
    let parteInteira = numeros.substring(0, posicaoDecimal);
    const parteDecimal = numeros.substring(posicaoDecimal);

    // Adiciona separador de milhares
    parteInteira = parteInteira.replace(/\B(?=(\d{3})+(?!\d))/g, config.separadorMilhares);

    // Monta o valor final
    let resultado = parteInteira + config.separadorDecimal + parteDecimal;

    // Adiciona prefixo e sufixo
    if (config.prefixo) resultado = config.prefixo + resultado;
    if (config.sufixo) resultado = resultado + config.sufixo;

    return resultado;
}

/**
 * Obtém o valor numérico real de um input monetário
 * @param {HTMLInputElement} input - Elemento input formatado
 * @returns {number} Valor numérico (ex: 1234.56)
 */
function obterValorNumerico(input) {
    const config = input._configMoeda || {
        separadorMilhares: '.',
        separadorDecimal: ','
    };

    let valor = input.value;

    // Remove prefixo e sufixo
    if (config.prefixo) valor = valor.replace(config.prefixo, '');
    if (config.sufixo) valor = valor.replace(config.sufixo, '');

    // Remove separadores de milhares e troca decimal
    valor = valor.replace(new RegExp('\\' + config.separadorMilhares, 'g'), '');
    valor = valor.replace(config.separadorDecimal, '.');

    return parseFloat(valor) || 0;
}

/**
 * Define o valor de um input monetário programaticamente
 * @param {HTMLInputElement} input - Elemento input
 * @param {number} valor - Valor numérico a definir
 */
function definirValorMonetario(input, valor) {
    const config = input._configMoeda || { casasDecimais: 2 };

    // Converte para centavos
    const centavos = Math.round(valor * Math.pow(10, config.casasDecimais)).toString();
    input.value = formatarValorMonetario(centavos, config);
}

// =====================================================
// COMO USAR
// =====================================================
//
// HTML:
// <input type="text" id="valor" placeholder="0,00">
//
// JavaScript:
// const input = document.getElementById('valor');
// inicializarInputMonetario(input);
//
// // Com prefixo R$:
// inicializarInputMonetario(input, { prefixo: 'R$ ' });
//
// // Para obter o valor numérico:
// const valorReal = obterValorNumerico(input); // retorna 1234.56
//
// // Para definir um valor programaticamente:
// definirValorMonetario(input, 1234.56); // mostra "1.234,56"

// Expor funções globalmente para uso em outros scripts
window.inicializarInputMonetario = inicializarInputMonetario;
window.obterValorNumerico = obterValorNumerico;
window.definirValorMonetario = definirValorMonetario;
