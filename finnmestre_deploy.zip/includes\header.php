﻿<?php
/**
 * =====================================================
 * FinnMestre - Header do Sistema
 * =====================================================
 */
require_once __DIR__ . '/auth.php';
require_once __DIR__ . '/functions.php';
require_once __DIR__ . '/perfis.php';

$paginaAtual = basename($_SERVER['PHP_SELF'], '.php');
$alertasNaoLidos = contarAlertasNaoLidos();
$alertas = listarAlertas(true, 5);
$finbotConfig = obterConfiguracao('finbot_ativo', true);
$finbotMensagem = $finbotConfig ? obterMensagemFinBot() : null;

// Perfis
$perfilAtual = obterPerfilAtual();
$listaPerfis = listarPerfis();
$modoConsolidado = isModoConsolidado();
?>
<!DOCTYPE html>
<html lang="pt-BR">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="FinnMestre - Sistema de Controle Financeiro Inteligente">
    <meta name="theme-color" content="#10b981">
    <title>FinnMestre - Controle Financeiro Inteligente</title>

    <!-- Favicon -->
    <link rel="icon" type="image/svg+xml"
        href="data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 100 100'%3E%3Cdefs%3E%3ClinearGradient id='g' x1='0%25' y1='0%25' x2='100%25' y2='100%25'%3E%3Cstop offset='0%25' stop-color='%2310b981'/%3E%3Cstop offset='100%25' stop-color='%23059669'/%3E%3C/linearGradient%3E%3C/defs%3E%3Crect width='100' height='100' rx='20' fill='url(%23g)'/%3E%3Ctext x='50' y='65' font-size='50' text-anchor='middle' fill='white' font-family='Arial' font-weight='bold'%3EFM%3C/text%3E%3C/svg%3E">

    <!-- CSS -->
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="assets/css/behavioral.css">
    <link rel="stylesheet" href="assets/css/theme-light.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">

    <!-- Chart.js -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

    <!-- Configuração de Moeda -->
    <script>
        <?php $moedaAtual = getMoedaAtual(); ?>
        const MOEDA_CONFIG = {
            simbolo: '<?= $moedaAtual['simbolo'] ?>',
            decimal: '<?= $moedaAtual['decimal'] ?>',
            milhares: '<?= $moedaAtual['milhares'] ?>'
        };
    </script>
    <script src="assets/js/moeda.js"></script>
    <script src="assets/js/moeda-input.js"></script>
    <script src="assets/js/behavioral.js"></script>
</head>

<body>
    <nav class="navbar">
        <div class="container">
            <!-- Logo -->
            <a href="index.php" class="logo">
                <div class="logo-icon">
                    <i class="fas fa-robot"></i>
                </div>
                <span class="logo-text">FinnMestre</span>
            </a>

            <!-- Navegação Principal -->
            <button class="mobile-menu-toggle" onclick="toggleMobileMenu()" id="mobileMenuToggle"
                style="display: none;">
                <i class="fas fa-bars"></i>
            </button>
            <ul class="nav-links" id="navLinks">
                <li>
                    <a href="index.php" class="<?= $paginaAtual === 'index' ? 'active' : '' ?>"
                        data-tooltip="<?= __('dashboard') ?>">
                        <i class="fas fa-chart-pie"></i>
                        <span><?= __('dashboard') ?></span>
                    </a>
                </li>
                <li>
                    <a href="transacoes.php" class="<?= $paginaAtual === 'transacoes' ? 'active' : '' ?>"
                        data-tooltip="<?= __('transacoes') ?>">
                        <i class="fas fa-exchange-alt"></i>
                        <span><?= __('transacoes') ?></span>
                    </a>
                </li>
                <li>
                    <a href="contas.php" class="<?= $paginaAtual === 'contas' ? 'active' : '' ?>"
                        data-tooltip="<?= __('contas') ?>">
                        <i class="fas fa-wallet"></i>
                        <span><?= __('contas') ?></span>
                    </a>
                </li>
                <li>
                    <a href="metas.php" class="<?= $paginaAtual === 'metas' ? 'active' : '' ?>"
                        data-tooltip="<?= __('metas') ?>">
                        <i class="fas fa-bullseye"></i>
                        <span><?= __('metas') ?></span>
                    </a>
                </li>
                <li>
                    <a href="contas-programadas.php"
                        class="<?= $paginaAtual === 'contas-programadas' ? 'active' : '' ?>" data-tooltip="Programadas">
                        <i class="fas fa-calendar-alt"></i>
                        <span>Programadas</span>
                    </a>
                </li>
                <li>
                    <a href="relatorios.php" class="<?= $paginaAtual === 'relatorios' ? 'active' : '' ?>"
                        data-tooltip="<?= __('relatorios') ?>">
                        <i class="fas fa-file-alt"></i>
                        <span><?= __('relatorios') ?></span>
                    </a>
                </li>
                <li>
                    <a href="assinatura.php" class="<?= $paginaAtual === 'assinatura' ? 'active' : '' ?>"
                        data-tooltip="Assinatura">
                        <i class="fas fa-crown"></i>
                        <span>Assinatura</span>
                    </a>
                </li>
                <li>
                    <a href="configuracoes.php" class="<?= $paginaAtual === 'configuracoes' ? 'active' : '' ?>"
                        data-tooltip="<?= __('configuracoes') ?>">
                        <i class="fas fa-cog"></i>
                        <span><?= __('configuracoes') ?></span>
                    </a>
                </li>
                <li>
                    <a href="suporte.php" class="<?= $paginaAtual === 'suporte' ? 'active' : '' ?>"
                        data-tooltip="Suporte">
                        <i class="fas fa-headset"></i>
                        <span>Suporte</span>
                    </a>
                </li>
                <?php if (isset($_SESSION['usuario_email']) && $_SESSION['usuario_email'] === 'poncianobryan988@gmail.com'): ?>
                    <li>
                        <a href="admin.php" class="<?= $paginaAtual === 'admin' ? 'active' : '' ?>" data-tooltip="Admin"
                            style="color: #f59e0b;">
                            <i class="fas fa-shield-alt"></i>
                            <span>Admin</span>
                        </a>
                    </li>
                <?php endif; ?>
            </ul>

            <!-- Área do Usuário -->
            <div class="nav-user">
                <!-- Seletor de Perfil -->
                <div class="profile-selector-wrapper">
                    <button class="btn-profile" onclick="toggleProfileDropdown()" id="btnProfile"
                        title="<?= $modoConsolidado ? 'Visão Consolidada' : 'Trocar Perfil' ?>">
                        <?php if ($modoConsolidado): ?>
                            <div class="profile-badge consolidado">
                                <i class="fas fa-layer-group"></i>
                            </div>
                            <span class="profile-name">Consolidado</span>
                        <?php elseif ($perfilAtual): ?>
                            <div class="profile-badge" style="background: <?= $perfilAtual['cor'] ?>;">
                                <i class="fas <?= $perfilAtual['icone'] ?>"></i>
                            </div>
                            <span class="profile-name"><?= htmlspecialchars($perfilAtual['nome']) ?></span>
                        <?php else: ?>
                            <div class="profile-badge">
                                <i class="fas fa-user"></i>
                            </div>
                            <span class="profile-name">Perfil</span>
                        <?php endif; ?>
                        <i class="fas fa-chevron-down profile-arrow"></i>
                    </button>

                    <!-- Dropdown de Perfis -->
                    <div class="profile-dropdown" id="profileDropdown">
                        <div class="profile-dropdown-header">
                            <h4><i class="fas fa-users"></i> Seus Perfis</h4>
                        </div>
                        <div class="profile-dropdown-list">
                            <?php foreach ($listaPerfis as $p): ?>
                                <a href="api/perfis.php?acao=trocar&id=<?= $p['id'] ?>"
                                    class="profile-dropdown-item <?= ($perfilAtual && $p['id'] == $perfilAtual['id'] && !$modoConsolidado) ? 'active' : '' ?>">
                                    <div class="profile-item-badge" style="background: <?= $p['cor'] ?>;">
                                        <i class="fas <?= $p['icone'] ?>"></i>
                                    </div>
                                    <span><?= htmlspecialchars($p['nome']) ?></span>
                                    <?php if ($perfilAtual && $p['id'] == $perfilAtual['id'] && !$modoConsolidado): ?>
                                        <i class="fas fa-check" style="margin-left: auto; color: var(--success);"></i>
                                    <?php endif; ?>
                                </a>
                            <?php endforeach; ?>
                        </div>
                        <div class="profile-dropdown-footer">
                            <a href="perfis.php" class="btn btn-primary btn-sm" style="width: 100%;">
                                <i class="fas fa-cog"></i> Gerenciar Perfis
                            </a>
                        </div>
                    </div>
                </div>

                <!-- Botão de Alertas -->
                <div style="position: relative;">
                    <button class="btn-alerts" onclick="toggleAlertas()" id="btnAlertas" title="Alertas">
                        <i class="fas fa-bell"></i>
                        <?php if ($alertasNaoLidos > 0): ?>
                            <span class="alert-count"><?= $alertasNaoLidos > 9 ? '9+' : $alertasNaoLidos ?></span>
                        <?php endif; ?>
                    </button>

                    <!-- Dropdown de Alertas -->
                    <div class="alerts-dropdown" id="alertasDropdown">
                        <div class="alerts-dropdown-header">
                            <h4><i class="fas fa-bell"></i> Notificações</h4>
                            <?php if ($alertasNaoLidos > 0): ?>
                                <button class="btn btn-ghost btn-sm" onclick="marcarTodosLidos()">
                                    Marcar todas
                                </button>
                            <?php endif; ?>
                        </div>
                        <div class="alerts-dropdown-body">
                            <?php if (empty($alertas)): ?>
                                <div class="empty-state" style="padding: 30px;">
                                    <i class="fas fa-check-circle" style="font-size: 2rem;"></i>
                                    <p style="margin-top: 10px;">Nenhuma notificação</p>
                                </div>
                            <?php else: ?>
                                <?php foreach ($alertas as $alerta): ?>
                                    <div class="alert-item" onclick="window.location='<?= $alerta['acao_url'] ?? '#' ?>'">
                                        <div class="alert-item-icon"
                                            style="background: <?= $alerta['cor'] ?>20; color: <?= $alerta['cor'] ?>;">
                                            <i class="fas <?= $alerta['icone'] ?>"></i>
                                        </div>
                                        <div class="alert-item-content">
                                            <div class="alert-item-title"><?= htmlspecialchars($alerta['titulo']) ?></div>
                                            <div class="alert-item-text"><?= htmlspecialchars($alerta['mensagem']) ?></div>
                                            <div class="alert-item-time">
                                                <i class="fas fa-clock"></i>
                                                <?= date('d/m H:i', strtotime($alerta['created_at'])) ?>
                                            </div>
                                        </div>
                                    </div>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>

                <!-- Botão Logout -->
                <a href="logout.php" class="btn-logout" title="Sair">
                    <i class="fas fa-sign-out-alt"></i>
                    <span>Sair</span>
                </a>
            </div>
        </div>
    </nav>

    <main class="container">

        <?php if ($finbotConfig && $finbotMensagem): ?>
            <!-- FinBot - Mascote Animado com Olhos que Seguem o Mouse -->
            <div class="finbot-container" id="finbotContainer">
                <!-- Mensagens do FinBot -->
                <div class="finbot-bubble" id="finbotBubble" style="display: none;">
                    <button onclick="fecharFinBot()"
                        style="position: absolute; top: 8px; right: 8px; background: none; border: none; color: var(--text-muted); cursor: pointer; font-size: 1rem;">
                        <i class="fas fa-times"></i>
                    </button>
                    <p style="font-weight: 600; margin-bottom: 8px; color: var(--text-secondary);">
                        <?= $finbotMensagem['saudacao'] ?>
                    </p>
                    <?php if (!empty($finbotMensagem['mensagens'])): ?>
                        <?php $msg = $finbotMensagem['mensagens'][0]; ?>
                        <div class="finbot-message">
                            <div class="finbot-message-icon"
                                style="background: <?= $msg['cor'] ?>20; color: <?= $msg['cor'] ?>;">
                                <i class="fas <?= $msg['icone'] ?>"></i>
                            </div>
                            <div class="finbot-message-text">
                                <?= $msg['texto'] ?>
                            </div>
                        </div>
                    <?php endif; ?>
                </div>

                <!-- Avatar do FinBot com Olhos Interativos -->
                <div class="finbot-avatar" id="finbotAvatar" onclick="toggleFinBot()"
                    title="Clique para ver dicas do FinBot">
                    <div class="finbot-face">
                        <div class="finbot-antenna"></div>
                        <div class="finbot-eyes">
                            <div class="finbot-eye"
                                style="width: 14px; height: 14px; display: flex; align-items: center; justify-content: center;">
                                <div class="finbot-pupil" id="pupilLeft"
                                    style="width: 6px; height: 6px; background: #1e293b; border-radius: 50%; transition: transform 0.1s ease;">
                                </div>
                            </div>
                            <div class="finbot-eye"
                                style="width: 14px; height: 14px; display: flex; align-items: center; justify-content: center;">
                                <div class="finbot-pupil" id="pupilRight"
                                    style="width: 6px; height: 6px; background: #1e293b; border-radius: 50%; transition: transform 0.1s ease;">
                                </div>
                            </div>
                        </div>
                        <div class="finbot-mouth"></div>
                    </div>
                </div>
            </div>

            <!-- Script para olhos seguirem o mouse -->
            <script>
                (function () {
                    const avatar = document.getElementById('finbotAvatar');
                    const pupilLeft = document.getElementById('pupilLeft');
                    const pupilRight = document.getElementById('pupilRight');

                    if (avatar && pupilLeft && pupilRight) {
                        document.addEventListener('mousemove', function (e) {
                            const rect = avatar.getBoundingClientRect();
                            const avatarCenterX = rect.left + rect.width / 2;
                            const avatarCenterY = rect.top + rect.height / 2;

                            const angle = Math.atan2(e.clientY - avatarCenterY, e.clientX - avatarCenterX);
                            const distance = Math.min(3, Math.hypot(e.clientX - avatarCenterX, e.clientY - avatarCenterY) / 80);

                            const moveX = Math.cos(angle) * distance;
                            const moveY = Math.sin(angle) * distance;

                            pupilLeft.style.transform = 'translate(' + moveX + 'px, ' + moveY + 'px)';
                            pupilRight.style.transform = 'translate(' + moveX + 'px, ' + moveY + 'px)';
                        });
                    }
                })();
            </script>
        <?php endif; ?>

        <script>
            // ==========================================
            // FUNÇÕES GLOBAIS DO HEADER
            // ==========================================

            // Toggle Alertas Dropdown
            function toggleAlertas() {
                const dropdown = document.getElementById('alertasDropdown');
                dropdown.classList.toggle('active');
                // Fechar dropdown de perfis
                document.getElementById('profileDropdown')?.classList.remove('active');
            }

            // Toggle Profile Dropdown
            function toggleProfileDropdown() {
                const dropdown = document.getElementById('profileDropdown');
                dropdown.classList.toggle('active');
                // Fechar dropdown de alertas
                document.getElementById('alertasDropdown')?.classList.remove('active');
            }

            // Fechar dropdowns ao clicar fora
            document.addEventListener('click', function (e) {
                const btnAlertas = document.getElementById('btnAlertas');
                const dropdownAlertas = document.getElementById('alertasDropdown');
                const btnProfile = document.getElementById('btnProfile');
                const dropdownProfile = document.getElementById('profileDropdown');

                if (btnAlertas && dropdownAlertas && !btnAlertas.contains(e.target) && !dropdownAlertas.contains(e.target)) {
                    dropdownAlertas.classList.remove('active');
                }
                if (btnProfile && dropdownProfile && !btnProfile.contains(e.target) && !dropdownProfile.contains(e.target)) {
                    dropdownProfile.classList.remove('active');
                }
            });

            // Marcar todos alertas como lidos
            function marcarTodosLidos() {
                fetch('api/alertas.php?acao=marcar_todos')
                    .then(r => r.json())
                    .then(d => {
                        if (d.sucesso) {
                            document.querySelector('.alert-count')?.remove();
                            document.querySelectorAll('.alert-item').forEach(el => el.style.opacity = '0.6');
                        }
                    });
            }

            // FinBot Functions
            let finbotAberto = false;

            function toggleFinBot() {
                const bubble = document.getElementById('finbotBubble');
                const avatar = document.querySelector('.finbot-avatar');

                finbotAberto = !finbotAberto;
                bubble.style.display = finbotAberto ? 'block' : 'none';

                if (finbotAberto) {
                    avatar.classList.add('finbot-celebration');
                    setTimeout(() => avatar.classList.remove('finbot-celebration'), 500);
                }
            }

            function fecharFinBot() {
                document.getElementById('finbotBubble').style.display = 'none';
                finbotAberto = false;
            }

            // Auto-mostrar FinBot após 3 segundos na primeira visita
            setTimeout(() => {
                if (!sessionStorage.getItem('finbot_shown')) {
                    const bubble = document.getElementById('finbotBubble');
                    if (bubble) {
                        bubble.style.display = 'block';
                        finbotAberto = true;
                        sessionStorage.setItem('finbot_shown', '1');
                    }
                }
            }, 3000);

            // Modal Functions
            function openModal(id) {
                document.getElementById(id).classList.add('active');
                document.body.style.overflow = 'hidden';
            }

            function closeModal(id) {
                document.getElementById(id).classList.remove('active');
                document.body.style.overflow = '';
            }

            // Fechar modal com ESC
            document.addEventListener('keydown', function (e) {
                if (e.key === 'Escape') {
                    document.querySelectorAll('.modal-overlay.active').forEach(el => {
                        el.classList.remove('active');
                    });
                    document.body.style.overflow = '';
                }
            });

            // Fechar modal ao clicar no overlay
            document.addEventListener('click', function (e) {
                if (e.target.classList.contains('modal-overlay')) {
                    e.target.classList.remove('active');
                    document.body.style.overflow = '';
                }
            });

            // Mobile Menu Toggle
            function toggleMobileMenu() {
                const navLinks = document.getElementById('navLinks');
                const toggle = document.getElementById('mobileMenuToggle');
                if (navLinks) {
                    navLinks.classList.toggle('active');
                    const icon = toggle.querySelector('i');
                    if (navLinks.classList.contains('active')) {
                        icon.className = 'fas fa-times';
                    } else {
                        icon.className = 'fas fa-bars';
                    }
                }
            }

            // Handle responsive navigation
            function handleResponsiveNav() {
                const mobileToggle = document.getElementById('mobileMenuToggle');
                const navLinks = document.getElementById('navLinks');

                if (window.innerWidth < 1024) {
                    if (mobileToggle) mobileToggle.style.display = 'flex';
                } else {
                    if (mobileToggle) mobileToggle.style.display = 'none';
                    if (navLinks) navLinks.classList.remove('active');
                }
            }

            // Run on load and resize
            handleResponsiveNav();
            window.addEventListener('resize', handleResponsiveNav);

            // Close mobile menu when clicking outside
            document.addEventListener('click', function (e) {
                const navLinks = document.getElementById('navLinks');
                const toggle = document.getElementById('mobileMenuToggle');
                if (navLinks && navLinks.classList.contains('active')) {
                    if (!navLinks.contains(e.target) && !toggle.contains(e.target)) {
                        navLinks.classList.remove('active');
                        toggle.querySelector('i').className = 'fas fa-bars';
                    }
                }
            });
        </script>