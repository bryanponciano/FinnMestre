﻿<?php
/**
 * =====================================================
 * FinnMestre - Dashboard Principal
 * =====================================================
 */
require_once 'includes/header.php';
require_once 'includes/quotes.php';

$mes = isset($_GET['mes']) ? intval($_GET['mes']) : date('m');
$ano = isset($_GET['ano']) ? intval($_GET['ano']) : date('Y');

// Dados do dashboard
$meses = getMeses();
$mesInt = is_numeric($mes) ? intval($mes) : 1;
$resumo = obterResumoMensal($mes, $ano);
$saldoTotal = obterSaldoTotal($mes, $ano);
$limiteMensal = obterLimiteMensal();
$percentualGasto = obterPercentualGasto($mes, $ano);
$gastosPorCategoria = obterGastosPorCategoria($mes, $ano);
$entradasVsSaidas = obterEntradasVsSaidas($ano);
$ultimasTransacoes = listarTransacoes(['mes' => $mes, 'ano' => $ano, 'limite' => 8]);
$resumoContas = obterResumoContas($mes, $ano);
$metas = listarMetas(true);
$gastosDiarios = obterGastosDiarios($mes, $ano);

// Dados comportamentais
$behavSalario = calcularPercentualSalarioRestante($mes, $ano);
$behavMicroPoupanca = calcularMicroPoupanca(15); // R$ 15/dia como padrão

// Dados do usuário para saudação
$apelido = $_SESSION['nome'] ?? 'Usuário';
if (isset($_SESSION['usuario_id'])) {
    try {
        $stmtUser = $pdo->prepare("SELECT nome FROM usuarios WHERE id = ?");
        $stmtUser->execute([$_SESSION['usuario_id']]);
        $dadosUser = $stmtUser->fetch();
        $apelido = $dadosUser['nome'] ?? 'Usuário';
        // Tentar pegar apelido se existir
        $firstName = explode(' ', $apelido)[0];
        $apelido = $firstName;
    } catch (Exception $e) {
        // Manter valor padrão
    }
}

// Determinar classe da barra de limite
if ($percentualGasto >= 90) {
    $barraClasse = 'danger';
} elseif ($percentualGasto >= 70) {
    $barraClasse = 'warning';
} else {
    $barraClasse = 'safe';
}
?>

<!-- Dashboard Header Integrado -->
<div class="dashboard-header animate-in" style="margin-bottom: 20px;">
    <!-- Saudação e Filtros lado a lado no bloco esquerdo -->
    <div>
        <h1
            style="font-size: 1.5rem; font-weight: 700; margin: 0 0 8px 0; display: flex; align-items: center; gap: 8px;">
            <span
                style="background: var(--fm-gradient-primary); -webkit-background-clip: text; -webkit-text-fill-color: transparent; background-clip: text;">
                Olá, <?= htmlspecialchars($apelido) ?>
            </span>
            <span style="font-size: 1.3rem;">👋</span>
        </h1>
        <div style="display: flex; align-items: center; gap: 16px; flex-wrap: wrap;">
            <p style="color: var(--fm-text-secondary); margin: 0; font-size: 0.9rem;">
                <i class="fas fa-chart-pie" style="color: var(--fm-primary); margin-right: 4px;"></i>
                Suas finanças em <strong><?= $meses[$mesInt] ?></strong> de <strong><?= $ano ?></strong>
            </p>
            <!-- Filtros de Período -->
            <form method="GET" style="display: flex; gap: 8px; align-items: center;">
                <select name="mes" class="form-control" style="min-width: 110px; padding: 6px 10px; font-size: 0.85rem;"
                    onchange="this.form.submit()">
                    <?php foreach ($meses as $num => $nome): ?>
                        <option value="<?= $num ?>" <?= $num == $mes ? 'selected' : '' ?>><?= $nome ?></option>
                    <?php endforeach; ?>
                </select>
                <select name="ano" class="form-control" style="min-width: 75px; padding: 6px 10px; font-size: 0.85rem;"
                    onchange="this.form.submit()">
                    <?php for ($a = date('Y') + 1; $a >= date('Y') - 5; $a--): ?>
                        <option value="<?= $a ?>" <?= $a == $ano ? 'selected' : '' ?>><?= $a ?></option>
                    <?php endfor; ?>
                </select>
            </form>
        </div>
    </div>
</div>

<!-- Cards de Resumo Principal -->
<div class="summary-cards">
    <!-- Patrimônio Total -->
    <div class="card animate-in">
        <div class="card-header">
            <span class="card-title"><?= __('patrimonio_total') ?></span>
            <div class="card-icon primary">
                <i class="fas fa-coins"></i>
            </div>
        </div>
        <div class="card-value <?= $saldoTotal >= 0 ? 'primary' : 'danger' ?>">
            <?= formatarMoeda($saldoTotal) ?>
        </div>
        <div class="card-subtitle"><?= __('saldo') ?></div>
    </div>

    <!-- Entradas do Mês -->
    <div class="card animate-in" style="animation-delay: 0.1s">
        <div class="card-header">
            <span class="card-title"><?= __('entradas_mes') ?></span>
            <div class="card-icon success">
                <i class="fas fa-arrow-up"></i>
            </div>
        </div>
        <div class="card-value success">
            <?= formatarMoeda($resumo['total_entradas']) ?>
        </div>
        <div class="card-subtitle"><?= __('entradas') ?></div>
    </div>

    <!-- Saídas do Mês -->
    <div class="card animate-in" style="animation-delay: 0.2s">
        <div class="card-header">
            <span class="card-title"><?= __('saidas_mes') ?></span>
            <div class="card-icon danger">
                <i class="fas fa-arrow-down"></i>
            </div>
        </div>
        <div class="card-value danger">
            <?= formatarMoeda($resumo['total_saidas']) ?>
        </div>
        <div class="card-subtitle"><?= __('saidas') ?></div>
    </div>

    <!-- Balanço do Mês -->
    <div class="card animate-in" style="animation-delay: 0.3s">
        <div class="card-header">
            <span class="card-title"><?= __('saldo_mes') ?></span>
            <div class="card-icon <?= $resumo['saldo'] >= 0 ? 'success' : 'danger' ?>">
                <i class="fas fa-calculator"></i>
            </div>
        </div>
        <div class="card-value <?= $resumo['saldo'] >= 0 ? 'success' : 'danger' ?>">
            <?= formatarMoeda($resumo['saldo']) ?>
        </div>
        <div class="card-subtitle">
            <?= __('balanco') ?>
        </div>
    </div>
</div>

<!-- Resumo por Tipo de Conta -->
<?php if (!empty($resumoContas)): ?>
    <div class="summary-cards" style="margin-bottom: 20px;">
        <!-- Conta Corrente -->
        <div class="card account-card corrente animate-in">
            <div class="card-header">
                <span class="card-title">Contas Correntes</span>
                <div class="card-icon secondary">
                    <i class="fas fa-university"></i>
                </div>
            </div>
            <div class="card-value" style="color: var(--fm-secondary);">
                <?= formatarMoeda($resumoContas['corrente']['total']) ?>
            </div>
            <div class="card-subtitle"><?= count($resumoContas['corrente']['contas']) ?> conta(s)</div>
        </div>

        <!-- Cartão de Crédito -->
        <div class="card account-card credito animate-in" style="animation-delay: 0.1s">
            <div class="card-header">
                <span class="card-title">Cartões de Crédito</span>
                <div class="card-icon warning">
                    <i class="fas fa-credit-card"></i>
                </div>
            </div>
            <div class="card-value" style="color: var(--warning);">
                <?= formatarMoeda(abs($resumoContas['credito']['usado'])) ?>
            </div>
            <div class="card-subtitle">
                <?php if ($resumoContas['credito']['limite_total'] > 0): ?>
                    de <?= formatarMoeda($resumoContas['credito']['limite_total']) ?> de limite
                <?php else: ?>
                    usado
                <?php endif; ?>
            </div>
        </div>

        <!-- Poupança -->
        <div class="card account-card poupanca animate-in" style="animation-delay: 0.2s">
            <div class="card-header">
                <span class="card-title">Poupança/Reservas</span>
                <div class="card-icon accent">
                    <i class="fas fa-piggy-bank"></i>
                </div>
            </div>
            <div class="card-value" style="color: var(--fm-accent);">
                <?= formatarMoeda($resumoContas['poupanca']['total']) ?>
            </div>
            <div class="card-subtitle"><?= count($resumoContas['poupanca']['contas']) ?> conta(s)</div>
        </div>

        <!-- Carteira -->
        <div class="card account-card carteira animate-in" style="animation-delay: 0.3s">
            <div class="card-header">
                <span class="card-title">Carteira/Dinheiro</span>
                <div class="card-icon success">
                    <i class="fas fa-wallet"></i>
                </div>
            </div>
            <div class="card-value success">
                <?= formatarMoeda($resumoContas['carteira']['total']) ?>
            </div>
            <div class="card-subtitle"><?= count($resumoContas['carteira']['contas']) ?> conta(s)</div>
        </div>
    </div>
<?php endif; ?>

<!-- Barra de Limite Mensal -->
<?php if ($limiteMensal > 0): ?>
    <div class="limit-card animate-in">
        <div class="limit-header">
            <span class="limit-title">
                <i class="fas fa-flag" style="color: var(--fm-primary);"></i>
                Limite Mensal de Gastos
            </span>
            <div class="limit-values">
                <span>Usado: <strong
                        class="<?= $barraClasse === 'safe' ? 'text-success' : ($barraClasse === 'warning' ? 'text-warning' : 'text-danger') ?>">
                        <?= formatarMoeda($resumo['total_saidas']) ?>
                    </strong></span>
                <span>Limite: <strong><?= formatarMoeda($limiteMensal) ?></strong></span>
            </div>
        </div>
        <div class="limit-bar">
            <div class="limit-progress <?= $barraClasse ?>" style="width: <?= min(100, $percentualGasto) ?>%"></div>
        </div>
        <?php if ($percentualGasto >= 70): ?>
            <div class="limit-alert <?= $barraClasse ?>">
                <i class="fas fa-exclamation-triangle"></i>
                <?php if ($percentualGasto >= 100): ?>
                    <strong>Limite ultrapassado!</strong> Você gastou <?= number_format($percentualGasto, 1) ?>% do limite mensal.
                <?php else: ?>
                    <strong>Atenção!</strong> Você já usou <?= number_format($percentualGasto, 1) ?>% do seu limite mensal.
                <?php endif; ?>
            </div>
        <?php endif; ?>
    </div>
<?php endif; ?>

<!-- =====================================================
     CARDS COMPORTAMENTAIS - Psicologia Financeira
     ===================================================== -->
<div class="behavioral-section"
    style="display: grid; grid-template-columns: repeat(2, 1fr); gap: 20px; margin-bottom: 24px;">

    <!-- Card: Percentual do Salário Restante -->
    <?php if ($behavSalario['configurado']): ?>
        <div class="behavioral-card <?= $behavSalario['classe'] ?> animate-in">
            <div class="behavioral-header">
                <div class="behavioral-icon">
                    <i class="fas fa-wallet"></i>
                </div>
                <div class="behavioral-title">
                    <h3>Quanto do seu salário ainda resta?</h3>
                    <span class="behavioral-subtitle">Consciência financeira imediata</span>
                </div>
            </div>
            <div class="behavioral-body">
                <div class="salary-display">
                    <div class="salary-percentage <?= $behavSalario['classe'] ?>">
                        <?= number_format($behavSalario['percentual'], 0) ?>%
                    </div>
                    <div class="salary-bar-container">
                        <div class="salary-bar <?= $behavSalario['classe'] ?>"
                            style="width: <?= min(100, $behavSalario['percentual']) ?>%"></div>
                    </div>
                </div>
                <div class="salary-details">
                    <div class="salary-item">
                        <span class="label">Salário:</span>
                        <span class="value"><?= formatarMoeda($behavSalario['salario']) ?></span>
                    </div>
                    <div class="salary-item">
                        <span class="label">Já gasto:</span>
                        <span class="value text-danger"><?= formatarMoeda($behavSalario['gasto']) ?></span>
                    </div>
                    <div class="salary-item">
                        <span class="label">Sobra:</span>
                        <span
                            class="value <?= $behavSalario['classe'] === 'danger' ? 'text-danger' : 'text-success' ?>"><?= formatarMoeda($behavSalario['sobra']) ?></span>
                    </div>
                </div>
                <div class="behavioral-message <?= $behavSalario['classe'] ?>">
                    <i
                        class="fas fa-<?= $behavSalario['classe'] === 'danger' ? 'exclamation-triangle' : ($behavSalario['classe'] === 'warning' ? 'exclamation-circle' : 'check-circle') ?>"></i>
                    <?= $behavSalario['mensagem'] ?>
                </div>
            </div>
        </div>
    <?php else: ?>
        <div class="behavioral-card setup animate-in">
            <div class="behavioral-header">
                <div class="behavioral-icon setup">
                    <i class="fas fa-cog"></i>
                </div>
                <div class="behavioral-title">
                    <h3>Configure seu salário</h3>
                    <span class="behavioral-subtitle">Desbloqueie análises de impacto</span>
                </div>
            </div>
            <div class="behavioral-body">
                <p style="color: var(--text-secondary); margin-bottom: 16px;">
                    Para ver quanto do seu salário ainda resta e calcular o custo em horas de vida de cada compra,
                    configure seu salário mensal.
                </p>
                <a href="configuracoes.php" class="btn btn-primary">
                    <i class="fas fa-cog"></i> Configurar Agora
                </a>
            </div>
        </div>
    <?php endif; ?>

    <!-- Card: Micro-Poupança Inteligente -->
    <div class="behavioral-card micro-savings animate-in" style="animation-delay: 0.1s;">
        <div class="behavioral-header">
            <div class="behavioral-icon savings">
                <i class="fas fa-piggy-bank"></i>
            </div>
            <div class="behavioral-title">
                <h3>O poder da economia diária</h3>
                <span class="behavioral-subtitle">Pequenos valores, grandes resultados</span>
            </div>
        </div>
        <div class="behavioral-body">
            <div class="micro-savings-display">
                <div class="micro-input-group">
                    <label>Se você guardar por dia:</label>
                    <div class="micro-input-wrapper">
                        <span class="currency">R$</span>
                        <input type="number" id="microValorDiario" value="15" min="1" max="500" step="1"
                            onchange="atualizarMicroPoupanca(this.value)">
                    </div>
                </div>
                <div class="micro-projections">
                    <div class="micro-projection">
                        <span class="micro-period">7 dias</span>
                        <span class="micro-value"
                            id="micro7dias"><?= formatarMoeda($behavMicroPoupanca['em_7_dias']) ?></span>
                    </div>
                    <div class="micro-projection">
                        <span class="micro-period">30 dias</span>
                        <span class="micro-value"
                            id="micro30dias"><?= formatarMoeda($behavMicroPoupanca['em_30_dias']) ?></span>
                    </div>
                    <div class="micro-projection highlight">
                        <span class="micro-period">1 ano</span>
                        <span class="micro-value"
                            id="micro1ano"><?= formatarMoeda($behavMicroPoupanca['em_1_ano']) ?></span>
                    </div>
                </div>
            </div>
            <div class="behavioral-message positive">
                <i class="fas fa-lightbulb"></i>
                <span id="microSugestao"><?= $behavMicroPoupanca['sugestao'] ?></span>
            </div>
            <button class="btn btn-success btn-sm" onclick="ativarMetaMicroPoupanca()" style="margin-top: 12px;">
                <i class="fas fa-check"></i> Ativar Meta Automática
            </button>
        </div>
    </div>
</div>



<!-- Metas em Destaque -->
<?php if (!empty($metas)): ?>
    <div class="form-card animate-in" style="padding: 20px;">
        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
            <h3 style="margin: 0;"><i class="fas fa-bullseye"></i> <?= __('metas') ?></h3>
            <a href="metas.php" class="btn btn-secondary btn-sm"><?= __('ver_todas') ?> <i
                    class="fas fa-arrow-right"></i></a>
        </div>
        <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(280px, 1fr)); gap: 16px;">
            <?php foreach (array_slice($metas, 0, 3) as $meta): ?>
                <div class="goal-card <?= $meta['prioridade'] ?>">
                    <div class="goal-header">
                        <div>
                            <div class="goal-title"><?= htmlspecialchars($meta['titulo']) ?></div>
                            <?php if ($meta['data_limite']): ?>
                                <?php
                                $diasRestantes = max(0, (strtotime($meta['data_limite']) - time()) / 86400);
                                ?>
                                <div class="goal-deadline <?= $diasRestantes <= 7 ? 'urgent' : '' ?>">
                                    <i class="fas fa-clock"></i>
                                    <?= $diasRestantes <= 0 ? __('vencida') : ceil($diasRestantes) . ' ' . __('dias_restantes') ?>
                                </div>
                            <?php endif; ?>
                        </div>
                        <div class="goal-percentage" style="color: <?= $meta['cor'] ?>;">
                            <?= number_format($meta['percentual'], 0) ?>%
                        </div>
                    </div>
                    <div class="goal-progress">
                        <div class="goal-progress-bar">
                            <div class="goal-progress-fill"
                                style="width: <?= $meta['percentual'] ?>%; background: <?= $meta['cor'] ?>;"></div>
                        </div>
                        <div class="goal-stats">
                            <span class="goal-current"><?= formatarMoeda($meta['valor_atual']) ?></span>
                            <span class="goal-target">de <?= formatarMoeda($meta['valor_objetivo']) ?></span>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
<?php endif; ?>

<!-- Gráficos -->
<div class="charts-grid">
    <!-- Gráfico de Pizza - Gastos por Categoria -->
    <div class="chart-card animate-in">
        <h3><i class="fas fa-chart-pie"></i> <?= __('gastos_categoria') ?></h3>
        <div class="chart-container">
            <?php if (empty($gastosPorCategoria)): ?>
                <div class="empty-state">
                    <i class="fas fa-chart-pie"></i>
                    <h4>Sem dados</h4>
                    <p>Nenhuma saída registrada este mês</p>
                </div>
            <?php else: ?>
                <canvas id="pieChart"></canvas>
            <?php endif; ?>
        </div>
    </div>

    <!-- Gráfico de Barras - Entradas vs Saídas -->
    <div class="chart-card animate-in" style="animation-delay: 0.1s">
        <h3><i class="fas fa-chart-bar"></i> Entradas vs Saídas (<?= $ano ?>)</h3>
        <div class="chart-container">
            <canvas id="barChart"></canvas>
        </div>
    </div>
</div>

<!-- Gráfico de Linha - Gastos Diários -->
<div class="chart-card animate-in" style="animation-delay: 0.2s; margin-bottom: 24px;">
    <h3><i class="fas fa-chart-line"></i> <?= __('gastos_diarios') ?> - <?= $meses[$mesInt] ?></h3>
    <p style="color: var(--text-muted); margin-bottom: 16px; font-size: 0.9rem;">
        Passe o mouse sobre os pontos para ver o valor gasto em cada dia
    </p>
    <div class="chart-container" style="height: 300px;">
        <?php if (array_sum($gastosDiarios) == 0): ?>
            <div class="empty-state">
                <i class="fas fa-chart-line"></i>
                <h4>Sem gastos</h4>
                <p>Nenhuma saída registrada este mês</p>
            </div>
        <?php else: ?>
            <canvas id="lineChart"></canvas>
        <?php endif; ?>
    </div>
</div>

<!-- Últimas Transações -->
<div class="table-card animate-in">
    <div class="table-header">
        <h3><i class="fas fa-history"></i> <?= __('ultimas_transacoes') ?></h3>
        <a href="transacoes.php" class="btn btn-secondary btn-sm">
            <?= __('ver_todas') ?> <i class="fas fa-arrow-right"></i>
        </a>
    </div>
    <div class="table-wrapper">
        <?php if (empty($ultimasTransacoes)): ?>
            <div class="empty-state">
                <i class="fas fa-inbox"></i>
                <h4>Nenhuma transação</h4>
                <p>Comece adicionando sua primeira transação</p>
                <a href="transacoes.php" class="btn btn-primary" style="margin-top: 20px;">
                    <i class="fas fa-plus"></i> Nova Transação
                </a>
            </div>
        <?php else: ?>
            <table>
                <thead>
                    <tr>
                        <th><?= __('data') ?></th>
                        <th><?= __('descricao') ?></th>
                        <th><?= __('categoria') ?></th>
                        <th><?= __('conta') ?></th>
                        <th><?= __('tipo') ?></th>
                        <th style="text-align: right;"><?= __('valor') ?></th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($ultimasTransacoes as $t): ?>
                        <tr>
                            <td><?= formatarData($t['data_transacao']) ?></td>
                            <td>
                                <strong><?= htmlspecialchars($t['descricao']) ?></strong>
                                <?php if ($t['total_parcelas'] > 1): ?>
                                    <small style="color: var(--text-muted);">
                                        (<?= $t['parcela_atual'] ?>/<?= $t['total_parcelas'] ?>)
                                    </small>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if ($t['categoria_nome']): ?>
                                    <span class="categoria-badge">
                                        <span class="categoria-dot" style="background: <?= $t['categoria_cor'] ?>"></span>
                                        <?= htmlspecialchars($t['categoria_nome']) ?>
                                    </span>
                                <?php else: ?>
                                    <span style="color: var(--text-muted);">-</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if ($t['conta_nome']): ?>
                                    <span class="conta-badge <?= $t['conta_tipo'] ?>">
                                        <i class="fas <?= getIconeTipoConta($t['conta_tipo']) ?>"></i>
                                        <?= htmlspecialchars($t['conta_nome']) ?>
                                    </span>
                                <?php else: ?>
                                    <span style="color: var(--text-muted);">-</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <span class="badge <?= $t['tipo'] ?>">
                                    <i
                                        class="fas fa-arrow-<?= $t['tipo'] === 'entrada' ? 'up' : ($t['tipo'] === 'transferencia' ? 'right' : 'down') ?>"></i>
                                    <?= ucfirst($t['tipo']) ?>
                                </span>
                            </td>
                            <td style="text-align: right;">
                                <strong class="<?= $t['tipo'] === 'entrada' ? 'text-success' : 'text-danger' ?>">
                                    <?= $t['tipo'] === 'entrada' ? '+' : '-' ?>         <?= formatarMoeda($t['valor']) ?>
                                </strong>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php endif; ?>
    </div>
</div>

<?php if (!empty($gastosPorCategoria) || !empty($entradasVsSaidas)): ?>
    <script>
        document.addEventListener('DOMContentLoaded', function () {
            // Configuração global do Chart.js
            Chart.defaults.color = '#94a3b8';
            Chart.defaults.font.family = 'Inter, sans-serif';

            <?php if (!empty($gastosPorCategoria)): ?>
                // Gráfico de Pizza - Gastos por Categoria
                const pieCtx = document.getElementById('pieChart');
                if (pieCtx) {
                    new Chart(pieCtx, {
                        type: 'doughnut',
                        data: {
                            labels: <?= json_encode(array_column($gastosPorCategoria, 'nome')) ?>,
                            datasets: [{
                                data: <?= json_encode(array_map('floatval', array_column($gastosPorCategoria, 'total'))) ?>,
                                backgroundColor: <?= json_encode(array_column($gastosPorCategoria, 'cor')) ?>,
                                borderWidth: 0,
                                hoverOffset: 15
                            }]
                        },
                        options: {
                            responsive: true,
                            maintainAspectRatio: false,
                            cutout: '65%',
                            plugins: {
                                legend: {
                                    position: 'right',
                                    labels: {
                                        padding: 15,
                                        usePointStyle: true,
                                        pointStyle: 'circle'
                                    }
                                },
                                tooltip: {
                                    callbacks: {
                                        label: function (context) {
                                            const total = context.dataset.data.reduce((a, b) => a + b, 0);
                                            const percentage = ((context.raw / total) * 100).toFixed(1);
                                            return context.label + ': R$ ' + context.raw.toLocaleString('pt-BR', { minimumFractionDigits: 2 }) + ' (' + percentage + '%)';
                                        }
                                    }
                                }
                            }
                        }
                    });
                }
            <?php endif; ?>

            // Gráfico de Barras - Entradas vs Saídas
            const barCtx = document.getElementById('barChart');
            if (barCtx) {
                const meses = ['Jan', 'Fev', 'Mar', 'Abr', 'Mai', 'Jun', 'Jul', 'Ago', 'Set', 'Out', 'Nov', 'Dez'];
                const dadosAno = <?= json_encode($entradasVsSaidas) ?>;

                const entradas = new Array(12).fill(0);
                const saidas = new Array(12).fill(0);

                dadosAno.forEach(d => {
                    entradas[d.mes - 1] = parseFloat(d.entradas);
                    saidas[d.mes - 1] = parseFloat(d.saidas);
                });

                new Chart(barCtx, {
                    type: 'bar',
                    data: {
                        labels: meses,
                        datasets: [
                            {
                                label: 'Entradas',
                                data: entradas,
                                backgroundColor: 'rgba(16, 185, 129, 0.8)',
                                borderColor: '#10b981',
                                borderWidth: 0,
                                borderRadius: 6,
                                borderSkipped: false
                            },
                            {
                                label: 'Saídas',
                                data: saidas,
                                backgroundColor: 'rgba(239, 68, 68, 0.8)',
                                borderColor: '#ef4444',
                                borderWidth: 0,
                                borderRadius: 6,
                                borderSkipped: false
                            }
                        ]
                    },
                    options: {
                        responsive: true,
                        maintainAspectRatio: false,
                        interaction: {
                            intersect: false,
                            mode: 'index'
                        },
                        plugins: {
                            legend: {
                                position: 'top',
                                labels: {
                                    usePointStyle: true,
                                    pointStyle: 'circle'
                                }
                            },
                            tooltip: {
                                callbacks: {
                                    label: function (context) {
                                        return context.dataset.label + ': R$ ' + context.raw.toLocaleString('pt-BR', { minimumFractionDigits: 2 });
                                    }
                                }
                            }
                        },
                        scales: {
                            x: {
                                grid: {
                                    display: false
                                }
                            },
                            y: {
                                beginAtZero: true,
                                grid: {
                                    color: 'rgba(148, 163, 184, 0.1)'
                                },
                                ticks: {
                                    callback: function (value) {
                                        return 'R$ ' + value.toLocaleString('pt-BR');
                                    }
                                }
                            }
                        }
                    }
                });
            }

            // Gráfico de Linha - Gastos Diários
            const lineCtx = document.getElementById('lineChart');
            if (lineCtx) {
                const gastosDiarios = <?= json_encode(array_values($gastosDiarios)) ?>;
                const diasDoMes = <?= json_encode(array_keys($gastosDiarios)) ?>;

                new Chart(lineCtx, {
                    type: 'line',
                    data: {
                        labels: diasDoMes,
                        datasets: [{
                            label: 'Gastos do Dia',
                            data: gastosDiarios,
                            borderColor: '#ef4444',
                            backgroundColor: 'rgba(239, 68, 68, 0.1)',
                            borderWidth: 3,
                            fill: true,
                            tension: 0.4,
                            pointRadius: 5,
                            pointHoverRadius: 10,
                            pointBackgroundColor: '#ef4444',
                            pointBorderColor: '#fff',
                            pointBorderWidth: 2,
                            pointHoverBackgroundColor: '#fff',
                            pointHoverBorderColor: '#ef4444',
                            pointHoverBorderWidth: 3
                        }]
                    },
                    options: {
                        responsive: true,
                        maintainAspectRatio: false,
                        interaction: {
                            intersect: false,
                            mode: 'index'
                        },
                        plugins: {
                            legend: {
                                display: false
                            },
                            tooltip: {
                                backgroundColor: 'rgba(15, 23, 42, 0.95)',
                                titleColor: '#fff',
                                bodyColor: '#fff',
                                borderColor: '#ef4444',
                                borderWidth: 1,
                                cornerRadius: 8,
                                padding: 12,
                                displayColors: false,
                                callbacks: {
                                    title: function (context) {
                                        return 'Dia ' + context[0].label;
                                    },
                                    label: function (context) {
                                        return 'Gasto: R$ ' + context.raw.toLocaleString('pt-BR', { minimumFractionDigits: 2 });
                                    }
                                }
                            }
                        },
                        scales: {
                            x: {
                                title: {
                                    display: true,
                                    text: 'Dia do Mês',
                                    color: '#94a3b8'
                                },
                                grid: {
                                    display: false
                                }
                            },
                            y: {
                                beginAtZero: true,
                                title: {
                                    display: true,
                                    text: 'Valor (R$)',
                                    color: '#94a3b8'
                                },
                                grid: {
                                    color: 'rgba(148, 163, 184, 0.1)'
                                },
                                ticks: {
                                    callback: function (value) {
                                        return 'R$ ' + value.toLocaleString('pt-BR');
                                    }
                                }
                            }
                        }
                    }
                });
            }
        });
    </script>
<?php endif; ?>

</main>
<script src="assets/js/app.js"></script>
</body>

</html>