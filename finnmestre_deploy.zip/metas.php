﻿<?php
/**
 * =====================================================
 * FinnMestre - Metas Financeiras
 * =====================================================
 */
require_once 'includes/header.php';

$mensagem = '';
$tipoMensagem = '';

// Processar formulário de meta
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['meta_titulo'])) {
    $dados = [
        'id' => !empty($_POST['meta_id']) ? intval($_POST['meta_id']) : null,
        'titulo' => trim($_POST['meta_titulo']),
        'descricao' => trim($_POST['meta_descricao'] ?? ''),
        'valor_objetivo' => floatval(str_replace(',', '.', str_replace('.', '', $_POST['meta_valor']))),
        'data_inicio' => $_POST['meta_data_inicio'] ?: date('Y-m-d'),
        'data_limite' => $_POST['meta_data_limite'] ?: null,
        'cor' => $_POST['meta_cor'] ?? '#10b981',
        'icone' => $_POST['meta_icone'] ?? 'fa-bullseye',
        'prioridade' => $_POST['meta_prioridade'] ?? 'media'
    ];

    if (salvarMeta($dados)) {
        $mensagem = $dados['id'] ? 'Meta atualizada com sucesso!' : 'Meta criada com sucesso!';
        $tipoMensagem = 'success';
    } else {
        $mensagem = 'Erro ao salvar meta.';
        $tipoMensagem = 'danger';
    }
}

// Adicionar/Remover contribuição
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['contribuicao_valor'])) {
    $metaId = intval($_POST['contribuicao_meta_id']);
    $valor = floatval(str_replace(',', '.', str_replace('.', '', $_POST['contribuicao_valor'])));
    $operacao = $_POST['contribuicao_operacao'] ?? 'adicionar';
    $obs = trim($_POST['contribuicao_obs'] ?? '');

    // Se for remover, inverte o sinal do valor
    if ($operacao === 'remover') {
        $valor = -abs($valor);
        $obs = $obs ?: 'Remoção de valor';
    }

    if (adicionarContribuicaoMeta($metaId, $valor, $obs)) {
        $mensagem = $operacao === 'remover' ? 'Valor removido com sucesso!' : 'Contribuição adicionada com sucesso!';
        $tipoMensagem = 'success';
    } else {
        $mensagem = 'Erro ao processar operação.';
        $tipoMensagem = 'danger';
    }
}

// Excluir meta
if (isset($_GET['excluir'])) {
    if (excluirMeta(intval($_GET['excluir']))) {
        $mensagem = 'Meta excluída com sucesso!';
        $tipoMensagem = 'success';
    } else {
        $mensagem = 'Erro ao excluir meta.';
        $tipoMensagem = 'danger';
    }
}

$metas = listarMetas(false);
$metasPendentes = array_filter($metas, fn($m) => !$m['concluida']);
$metasConcluidas = array_filter($metas, fn($m) => $m['concluida']);

// Estatísticas
$totalObjetivo = array_sum(array_column($metasPendentes, 'valor_objetivo'));
$totalAtual = array_sum(array_column($metasPendentes, 'valor_atual'));
$percentualGeral = $totalObjetivo > 0 ? ($totalAtual / $totalObjetivo) * 100 : 0;

// Ícones disponíveis
$iconesDisponiveis = [
    'fa-bullseye' => 'Alvo',
    'fa-home' => 'Casa',
    'fa-car' => 'Carro',
    'fa-plane' => 'Viagem',
    'fa-graduation-cap' => 'Educação',
    'fa-laptop' => 'Tecnologia',
    'fa-ring' => 'Casamento',
    'fa-baby' => 'Bebê',
    'fa-piggy-bank' => 'Reserva',
    'fa-heart' => 'Saúde',
    'fa-gift' => 'Presente',
    'fa-star' => 'Especial'
];
?>

<div class="page-header">
    <h1><i class="fas fa-bullseye" style="color: var(--fm-primary);"></i> <?= __('suas_metas') ?></h1>
    <p><?= __('gerencie_metas') ?></p>
</div>

<?php if ($mensagem): ?>
    <div class="alert alert-<?= $tipoMensagem ?>">
        <i class="fas fa-<?= $tipoMensagem === 'success' ? 'check-circle' : 'exclamation-circle' ?>"></i>
        <?= $mensagem ?>
    </div>
<?php endif; ?>

<!-- Resumo das Metas -->
<div class="summary-cards">
    <div class="card animate-in">
        <div class="card-header">
            <span class="card-title">Metas Ativas</span>
            <div class="card-icon primary">
                <i class="fas fa-flag"></i>
            </div>
        </div>
        <div class="card-value primary">
            <?= count($metasPendentes) ?>
        </div>
        <div class="card-subtitle">objetivos em andamento</div>
    </div>

    <div class="card animate-in" style="animation-delay: 0.1s">
        <div class="card-header">
            <span class="card-title">Total a Alcançar</span>
            <div class="card-icon accent">
                <i class="fas fa-mountain"></i>
            </div>
        </div>
        <div class="card-value accent">
            <?= formatarMoeda($totalObjetivo) ?>
        </div>
        <div class="card-subtitle">soma de todas as metas</div>
    </div>

    <div class="card animate-in" style="animation-delay: 0.2s">
        <div class="card-header">
            <span class="card-title">Já Conquistado</span>
            <div class="card-icon success">
                <i class="fas fa-trophy"></i>
            </div>
        </div>
        <div class="card-value success">
            <?= formatarMoeda($totalAtual) ?>
        </div>
        <div class="card-subtitle">
            <?= number_format($percentualGeral, 1) ?>% do total
        </div>
    </div>

    <div class="card animate-in" style="animation-delay: 0.3s">
        <div class="card-header">
            <span class="card-title">Metas Concluídas</span>
            <div class="card-icon warning">
                <i class="fas fa-medal"></i>
            </div>
        </div>
        <div class="card-value warning">
            <?= count($metasConcluidas) ?>
        </div>
        <div class="card-subtitle">objetivos alcançados 🎉</div>
    </div>
</div>

<!-- Botão Nova Meta -->
<div style="margin-bottom: 24px;">
    <button onclick="novaMeta()" class="btn btn-primary">
        <i class="fas fa-plus"></i> <?= __('nova_meta') ?>
    </button>
</div>

<!-- Grid de Metas -->
<?php if (empty($metasPendentes)): ?>
    <div class="form-card">
        <div class="empty-state">
            <i class="fas fa-bullseye"></i>
            <h4><?= __('nenhuma_meta') ?></h4>
            <p><?= __('crie_primeira_meta') ?></p>
            <button onclick="novaMeta()" class="btn btn-primary" style="margin-top: 20px;">
                <i class="fas fa-plus"></i> <?= __('nova_meta') ?>
            </button>
        </div>
    </div>
<?php else: ?>
    <div
        style="display: grid; grid-template-columns: repeat(auto-fit, minmax(340px, 1fr)); gap: 20px; margin-bottom: 30px;">
        <?php foreach ($metasPendentes as $meta): ?>
            <?php
            $diasRestantes = $meta['data_limite'] ? max(0, (strtotime($meta['data_limite']) - time()) / 86400) : null;
            $urgente = $diasRestantes !== null && $diasRestantes <= 7;
            ?>
            <div class="goal-card <?= $meta['prioridade'] ?> animate-in" style="animation-delay: 0.1s;">
                <div class="goal-header">
                    <div style="display: flex; gap: 14px; align-items: flex-start;">
                        <div class="goal-icon" style="background: <?= $meta['cor'] ?>20; color: <?= $meta['cor'] ?>;">
                            <i class="fas <?= $meta['icone'] ?>"></i>
                        </div>
                        <div>
                            <div class="goal-title">
                                <?= htmlspecialchars($meta['titulo']) ?>
                            </div>
                            <?php if ($meta['descricao']): ?>
                                <div class="goal-desc">
                                    <?= htmlspecialchars($meta['descricao']) ?>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="btn-group" style="flex-shrink: 0;">
                        <button onclick='editarMeta(<?= json_encode($meta) ?>)' class="btn btn-icon btn-ghost btn-sm"
                            title="Editar">
                            <i class="fas fa-edit"></i>
                        </button>
                        <a href="?excluir=<?= $meta['id'] ?>" onclick="return confirm('Excluir esta meta?')"
                            class="btn btn-icon btn-ghost btn-sm" title="Excluir" style="color: var(--danger);">
                            <i class="fas fa-trash"></i>
                        </a>
                    </div>
                </div>

                <div class="goal-progress">
                    <div class="goal-progress-bar">
                        <div class="goal-progress-fill"
                            style="width: <?= $meta['percentual'] ?>%; background: <?= $meta['cor'] ?>;"></div>
                    </div>
                    <div class="goal-stats">
                        <span class="goal-current" style="color: <?= $meta['cor'] ?>;">
                            <?= formatarMoeda($meta['valor_atual']) ?>
                        </span>
                        <span class="goal-target">de
                            <?= formatarMoeda($meta['valor_objetivo']) ?>
                        </span>
                    </div>
                </div>

                <!-- Calculadora de dias para bater a meta -->
                <?php
                $falta = $meta['valor_objetivo'] - $meta['valor_atual'];
                $diasCriacao = max(1, (time() - strtotime($meta['data_inicio'])) / 86400);
                $mediaContribuicao = $meta['valor_atual'] / $diasCriacao;
                $diasParaBater = $mediaContribuicao > 0 ? ceil($falta / $mediaContribuicao) : 0;
                ?>
                <?php if ($falta > 0 && $meta['valor_atual'] > 0): ?>
                    <div
                        style="background: var(--bg-glass-light); padding: 12px 14px; border-radius: var(--radius-md); margin-top: 12px; display: flex; align-items: center; gap: 10px;">
                        <i class="fas fa-calculator" style="color: var(--fm-primary);"></i>
                        <div style="font-size: 0.85rem; color: var(--text-secondary);">
                            <strong style="color: <?= $meta['cor'] ?>;">~<?= $diasParaBater ?> dias</strong> para atingir
                            (baseado na média de <?= formatarMoeda($mediaContribuicao) ?>/dia)
                        </div>
                    </div>
                <?php endif; ?>

                <div style="display: flex; justify-content: space-between; align-items: center; margin-top: 16px;">
                    <?php if ($meta['data_limite']): ?>
                        <div class="goal-deadline <?= $urgente ? 'urgent' : '' ?>">
                            <i class="fas fa-clock"></i>
                            <?php if ($diasRestantes <= 0): ?>
                                Vencida!
                            <?php else: ?>
                                <?= ceil($diasRestantes) ?> dias restantes
                            <?php endif; ?>
                        </div>
                    <?php else: ?>
                        <div class="goal-deadline">
                            <i class="fas fa-infinity"></i> Sem prazo
                        </div>
                    <?php endif; ?>

                    <div style="display: flex; gap: 8px;">
                        <button
                            onclick="abrirContribuicao(<?= $meta['id'] ?>, '<?= htmlspecialchars($meta['titulo']) ?>', 'adicionar')"
                            class="btn btn-sm" style="background: <?= $meta['cor'] ?>; color: white;">
                            <i class="fas fa-plus"></i> Adicionar
                        </button>
                        <?php if ($meta['valor_atual'] > 0): ?>
                            <button
                                onclick="abrirContribuicao(<?= $meta['id'] ?>, '<?= htmlspecialchars($meta['titulo']) ?>', 'remover')"
                                class="btn btn-sm btn-ghost" style="color: var(--danger);">
                                <i class="fas fa-minus"></i>
                            </button>
                        <?php endif; ?>
                    </div>
                </div>

                <!-- Barra de prioridade -->
                <div
                    style="position: absolute; top: 0; left: 0; right: 0; height: 4px; border-radius: var(--radius-lg) var(--radius-lg) 0 0; overflow: hidden;">
                    <?php
                    $corPrioridade = match ($meta['prioridade']) {
                        'alta' => 'var(--danger)',
                        'media' => 'var(--warning)',
                        default => 'var(--success)'
                    };
                    ?>
                    <div style="height: 100%; background: <?= $corPrioridade ?>;"></div>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
<?php endif; ?>

<!-- Metas Concluídas -->
<?php if (!empty($metasConcluidas)): ?>
    <div class="form-card" style="margin-top: 30px;">
        <h3><i class="fas fa-trophy" style="color: var(--warning);"></i> Metas Concluídas 🎉</h3>
        <div
            style="display: grid; grid-template-columns: repeat(auto-fit, minmax(280px, 1fr)); gap: 16px; margin-top: 20px;">
            <?php foreach ($metasConcluidas as $meta): ?>
                <div
                    style="padding: 16px; background: var(--success-light); border: 1px solid rgba(16, 185, 129, 0.3); border-radius: var(--radius-md); display: flex; align-items: center; gap: 14px;">
                    <div
                        style="width: 45px; height: 45px; border-radius: 50%; background: var(--success); color: white; display: flex; align-items: center; justify-content: center;">
                        <i class="fas fa-check"></i>
                    </div>
                    <div style="flex: 1;">
                        <div style="font-weight: 600;">
                            <?= htmlspecialchars($meta['titulo']) ?>
                        </div>
                        <div style="font-size: 0.85rem; color: var(--text-muted);">
                            Alcançado:
                            <?= formatarMoeda($meta['valor_objetivo']) ?>
                        </div>
                    </div>
                    <i class="fas fa-medal" style="font-size: 1.5rem; color: var(--warning);"></i>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
<?php endif; ?>

<!-- Modal Nova/Editar Meta -->
<div id="modalMeta" class="modal-overlay">
    <div class="modal" style="max-width: 550px;">
        <div class="modal-header">
            <h3><i class="fas fa-bullseye"></i> <span id="modalMetaTitulo">Nova Meta</span></h3>
            <button class="modal-close" onclick="closeModal('modalMeta')">&times;</button>
        </div>
        <form method="POST">
            <div class="modal-body">
                <input type="hidden" id="meta_id" name="meta_id">

                <div class="form-group">
                    <label class="required">Título da Meta</label>
                    <input type="text" id="meta_titulo" name="meta_titulo" class="form-control" required
                        placeholder="Ex: Reserva de Emergência, Viagem, etc.">
                </div>

                <div class="form-group">
                    <label>Descrição</label>
                    <textarea id="meta_descricao" name="meta_descricao" class="form-control" rows="2"
                        placeholder="Detalhes sobre sua meta (opcional)"></textarea>
                </div>

                <div class="form-group">
                    <label class="required">Valor Objetivo</label>
                    <input type="text" id="meta_valor" name="meta_valor" class="form-control input-moeda" required
                        placeholder="0,00">
                </div>

                <div class="form-grid" style="grid-template-columns: 1fr 1fr;">
                    <div class="form-group">
                        <label>Data Início</label>
                        <input type="date" id="meta_data_inicio" name="meta_data_inicio" class="form-control"
                            value="<?= date('Y-m-d') ?>">
                    </div>
                    <div class="form-group">
                        <label>Data Limite</label>
                        <input type="date" id="meta_data_limite" name="meta_data_limite" class="form-control">
                        <span class="form-hint">Deixe vazio se não tiver prazo</span>
                    </div>
                </div>

                <div class="form-grid" style="grid-template-columns: 1fr 1fr 1fr;">
                    <div class="form-group">
                        <label>Prioridade</label>
                        <select id="meta_prioridade" name="meta_prioridade" class="form-control">
                            <option value="baixa">🟢 Baixa</option>
                            <option value="media" selected>🟡 Média</option>
                            <option value="alta">🔴 Alta</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Cor</label>
                        <input type="color" id="meta_cor" name="meta_cor" class="form-control" value="#10b981"
                            style="height: 46px; padding: 5px;">
                    </div>
                    <div class="form-group">
                        <label>Ícone</label>
                        <select id="meta_icone" name="meta_icone" class="form-control">
                            <?php foreach ($iconesDisponiveis as $classe => $nome): ?>
                                <option value="<?= $classe ?>">
                                    <?= $nome ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" onclick="closeModal('modalMeta')">Cancelar</button>
                <button type="submit" class="btn btn-primary">
                    <i class="fas fa-save"></i> Salvar
                </button>
            </div>
        </form>
    </div>
</div>

<!-- Modal Contribuição -->
<div id="modalContribuicao" class="modal-overlay">
    <div class="modal" style="max-width: 400px;">
        <div class="modal-header">
            <h3><i class="fas fa-plus-circle"></i> Adicionar Contribuição</h3>
            <button class="modal-close" onclick="closeModal('modalContribuicao')">&times;</button>
        </div>
        <form method="POST" id="formContribuicao">
            <div class="modal-body">
                <input type="hidden" id="contribuicao_meta_id" name="contribuicao_meta_id">
                <input type="hidden" id="contribuicao_operacao" name="contribuicao_operacao" value="adicionar">

                <p style="margin-bottom: 20px; color: var(--text-secondary);">
                    Contribuindo para: <strong id="contribuicaoMetaNome"></strong>
                </p>

                <div class="form-group">
                    <label class="required">Valor</label>
                    <input type="text" id="contribuicao_valor" name="contribuicao_valor"
                        class="form-control input-moeda" required placeholder="0,00">
                </div>

                <div class="form-group">
                    <label>Observação</label>
                    <input type="text" id="contribuicao_obs" name="contribuicao_obs" class="form-control"
                        placeholder="Ex: Depósito mensal (opcional)">
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary"
                    onclick="closeModal('modalContribuicao')">Cancelar</button>
                <button type="submit" class="btn btn-success">
                    <i class="fas fa-plus"></i> Adicionar
                </button>
            </div>
        </form>
    </div>
</div>

<script>
    // Inicializar inputs monetários
    document.addEventListener('DOMContentLoaded', function () {
        const inputMetaValor = document.getElementById('meta_valor');
        const inputContribValor = document.getElementById('contribuicao_valor');

        if (inputMetaValor && typeof inicializarInputMonetario === 'function') {
            inicializarInputMonetario(inputMetaValor);
        }
        if (inputContribValor && typeof inicializarInputMonetario === 'function') {
            inicializarInputMonetario(inputContribValor);
        }
    });

    function novaMeta() {
        document.getElementById('modalMetaTitulo').textContent = 'Nova Meta';
        document.getElementById('meta_id').value = '';
        document.getElementById('meta_titulo').value = '';
        document.getElementById('meta_descricao').value = '';
        definirValorMonetario(document.getElementById('meta_valor'), 0);
        document.getElementById('meta_data_inicio').value = new Date().toISOString().split('T')[0];
        document.getElementById('meta_data_limite').value = '';
        document.getElementById('meta_prioridade').value = 'media';
        document.getElementById('meta_cor').value = '#10b981';
        document.getElementById('meta_icone').value = 'fa-bullseye';
        openModal('modalMeta');
    }

    function editarMeta(meta) {
        document.getElementById('modalMetaTitulo').textContent = 'Editar Meta';
        document.getElementById('meta_id').value = meta.id;
        document.getElementById('meta_titulo').value = meta.titulo;
        document.getElementById('meta_descricao').value = meta.descricao || '';
        definirValorMonetario(document.getElementById('meta_valor'), parseFloat(meta.valor_objetivo));
        document.getElementById('meta_data_inicio').value = meta.data_inicio || '';
        document.getElementById('meta_data_limite').value = meta.data_limite || '';
        document.getElementById('meta_prioridade').value = meta.prioridade || 'media';
        document.getElementById('meta_cor').value = meta.cor || '#10b981';
        document.getElementById('meta_icone').value = meta.icone || 'fa-bullseye';
        openModal('modalMeta');
    }

    function abrirContribuicao(metaId, metaNome, tipo = 'adicionar') {
        document.getElementById('contribuicao_meta_id').value = metaId;
        document.getElementById('contribuicaoMetaNome').textContent = metaNome;
        document.getElementById('contribuicao_valor').value = '';
        document.getElementById('contribuicao_obs').value = '';

        const titulo = document.querySelector('#modalContribuicao .modal-header h3');
        const btnSubmit = document.querySelector('#modalContribuicao .btn-success');
        const inputValor = document.getElementById('contribuicao_valor');

        if (tipo === 'remover') {
            titulo.innerHTML = '<i class="fas fa-minus-circle"></i> Remover Valor';
            btnSubmit.innerHTML = '<i class="fas fa-minus"></i> Remover';
            btnSubmit.classList.remove('btn-success');
            btnSubmit.classList.add('btn-danger');
            inputValor.setAttribute('data-operacao', 'remover');
            document.getElementById('contribuicao_operacao').value = 'remover';
        } else {
            titulo.innerHTML = '<i class="fas fa-plus-circle"></i> Adicionar Contribuição';
            btnSubmit.innerHTML = '<i class="fas fa-plus"></i> Adicionar';
            btnSubmit.classList.remove('btn-danger');
            btnSubmit.classList.add('btn-success');
            inputValor.setAttribute('data-operacao', 'adicionar');
            document.getElementById('contribuicao_operacao').value = 'adicionar';
        }

        openModal('modalContribuicao');
    }
</script>

</main>
<script src="assets/js/app.js"></script>
</body>

</html>