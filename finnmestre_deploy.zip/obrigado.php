﻿<?php
/**
 * =====================================================
 * FinnMestre - Thank You Page
 * Página de confirmação após checkout
 * =====================================================
 */
session_start();

$sucesso = $_SESSION['checkout_sucesso'] ?? false;
$plano = $_SESSION['checkout_plano'] ?? 'mensal';
$forma = $_SESSION['checkout_forma'] ?? 'pix';
$email = $_SESSION['checkout_email'] ?? '';

// Limpar sessão de checkout
unset($_SESSION['checkout_sucesso'], $_SESSION['checkout_plano'], $_SESSION['checkout_forma'], $_SESSION['checkout_email']);

$planos = [
    'mensal' => 'Mensal',
    'semestral' => 'Semestral',
    'anual' => 'Anual'
];

$isPending = ($forma === 'boleto');
?>
<!DOCTYPE html>
<html lang="pt-BR">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Obrigado! — FinnMestre</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link rel="stylesheet" href="assets/css/public.css">
</head>

<body>
    <!-- Navigation -->
    <nav class="public-nav">
        <div class="nav-container">
            <a href="home.php" class="nav-logo">
                <span class="logo-icon">📊</span>
                <span class="logo-text">FinnMestre</span>
            </a>
        </div>
    </nav>

    <div class="thankyou-page">
        <?php if ($isPending): ?>
            <!-- Boleto: Aguardando pagamento -->
            <div class="thankyou-card">
                <div class="thankyou-icon pending">
                    <i class="fas fa-clock"></i>
                </div>
                <h1 class="thankyou-title">Quase lá!</h1>
                <p class="thankyou-message">
                    Seu cadastro foi realizado com sucesso. Estamos aguardando a confirmação
                    do pagamento do boleto.
                </p>

                <div
                    style="background: rgba(245, 158, 11, 0.1); border: 1px solid var(--warning); padding: 20px; border-radius: var(--radius-md); margin-bottom: 32px; text-align: left;">
                    <div style="display: flex; align-items: center; gap: 10px; color: var(--warning); margin-bottom: 12px;">
                        <i class="fas fa-info-circle"></i>
                        <strong>Importante sobre pagamento via Boleto</strong>
                    </div>
                    <p style="color: var(--text-secondary); font-size: 0.95rem;">
                        Boletos podem levar <strong>até 1 dia útil</strong> para serem compensados pelo banco.
                        Assim que o pagamento for confirmado, seu acesso será liberado automaticamente e
                        você receberá um email de confirmação.
                    </p>
                </div>

                <div class="thankyou-steps">
                    <h4>Próximos passos:</h4>
                    <ol>
                        <li>Verifique seu email para o boleto</li>
                        <li>Efetue o pagamento do boleto</li>
                        <li>Aguarde a confirmação (até 1 dia útil)</li>
                        <li>Receba o email de liberação de acesso</li>
                        <li>Acesse o FinnMestre e comece a usar!</li>
                    </ol>
                </div>

                <p style="color: var(--text-muted); margin-bottom: 24px;">
                    Enviamos as instruções para: <strong style="color: var(--text-primary);">
                        <?= htmlspecialchars($email) ?>
                    </strong>
                </p>

                <a href="login.php" class="btn-access"
                    style="background: var(--bg-glass); border: 2px solid var(--border-color);">
                    <i class="fas fa-sign-in-alt"></i>
                    Ir para Login
                </a>

                <p style="color: var(--text-muted); font-size: 0.85rem; margin-top: 24px;">
                    Dúvidas? Entre em contato: <a href="mailto:suporte@FinnMestre.com"
                        style="color: var(--primary-light);">suporte@FinnMestre.com</a>
                </p>
            </div>
        <?php else: ?>
            <!-- PIX/Cartão: Acesso liberado -->
            <div class="thankyou-card">
                <div class="thankyou-icon">
                    <i class="fas fa-check"></i>
                </div>
                <h1 class="thankyou-title">Pagamento Confirmado!</h1>
                <p class="thankyou-message">
                    Parabéns! Sua assinatura do plano <strong>
                        <?= $planos[$plano] ?>
                    </strong> foi ativada
                    com sucesso. Seu acesso está liberado!
                </p>

                <div class="thankyou-steps">
                    <h4>Primeiros passos:</h4>
                    <ol>
                        <li>Acesse o dashboard com seu email e senha</li>
                        <li>Configure seu salário mensal nas configurações</li>
                        <li>Cadastre suas contas e cartões</li>
                        <li>Comece a registrar suas transações</li>
                        <li>Defina suas primeiras metas financeiras</li>
                    </ol>
                </div>

                <a href="login.php" class="btn-access">
                    <i class="fas fa-rocket"></i>
                    Acessar o FinnMestre
                </a>

                <p style="color: var(--text-muted); font-size: 0.85rem; margin-top: 24px;">
                    Enviamos os detalhes da sua assinatura para: <strong style="color: var(--text-primary);">
                        <?= htmlspecialchars($email) ?>
                    </strong>
                </p>
            </div>
        <?php endif; ?>
    </div>

    <!-- Confetti Animation for Success -->
    <?php if (!$isPending && $sucesso): ?>
        <script>
            // Simple confetti effect
            function createConfetti() {
                const colors = ['#8b5cf6', '#06b6d4', '#10b981', '#f59e0b', '#ef4444'];
                for (let i = 0; i < 100; i++) {
                    const confetti = document.createElement('div');
                    confetti.style.cssText = `
                    position: fixed;
                    width: 10px;
                    height: 10px;
                    background: ${colors[Math.floor(Math.random() * colors.length)]};
                    top: -10px;
                    left: ${Math.random() * 100}vw;
                    opacity: ${Math.random() + 0.5};
                    border-radius: ${Math.random() > 0.5 ? '50%' : '0'};
                    pointer-events: none;
                    animation: fall ${Math.random() * 3 + 2}s linear forwards;
                `;
                    document.body.appendChild(confetti);
                    setTimeout(() => confetti.remove(), 5000);
                }
            }

            const style = document.createElement('style');
            style.textContent = `
            @keyframes fall {
                to {
                    transform: translateY(110vh) rotate(720deg);
                    opacity: 0;
                }
            }
        `;
            document.head.appendChild(style);

            createConfetti();
        </script>
    <?php endif; ?>
</body>

</html>