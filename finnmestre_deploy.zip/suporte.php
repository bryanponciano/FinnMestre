﻿<?php
/**
 * =====================================================
 * FinnMestre - Página de Suporte
 * =====================================================
 */
session_start();
require_once 'config/database.php';

// Verificar se é admin (para configurar WhatsApp)
$isAdmin = isset($_SESSION['usuario_email']) && $_SESSION['usuario_email'] === 'poncianobryan988@gmail.com';

// Configurações de contato
try {
    $stmt = $pdo->query("SELECT valor FROM configuracoes WHERE chave = 'whatsapp_suporte'");
    $result = $stmt->fetch();
    $whatsappNumero = $result ? $result['valor'] : '';
} catch (Exception $e) {
    $whatsappNumero = '';
}

// Salvar configuração de WhatsApp (apenas admin)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && $isAdmin && isset($_POST['whatsapp_numero'])) {
    $numero = preg_replace('/\D/', '', $_POST['whatsapp_numero']);
    try {
        $stmt = $pdo->prepare("INSERT INTO configuracoes (chave, valor, tipo, descricao) 
            VALUES ('whatsapp_suporte', ?, 'string', 'Número do WhatsApp de suporte') 
            ON DUPLICATE KEY UPDATE valor = ?");
        $stmt->execute([$numero, $numero]);
        $whatsappNumero = $numero;
        $mensagemSucesso = 'Número de WhatsApp atualizado!';
    } catch (Exception $e) {
        $mensagemErro = 'Erro ao salvar número.';
    }
}

$emailSuporte = 'suporte@FinnMestre.com.br';
?>
<!DOCTYPE html>
<html lang="pt-BR">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Suporte FinnMestre - Estamos aqui para ajudar">
    <title>Suporte - FinnMestre</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="icon" type="image/svg+xml"
        href="data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 100 100'%3E%3Cdefs%3E%3ClinearGradient id='g' x1='0%25' y1='0%25' x2='100%25' y2='100%25'%3E%3Cstop offset='0%25' stop-color='%2310b981'/%3E%3Cstop offset='100%25' stop-color='%23059669'/%3E%3C/linearGradient%3E%3C/defs%3E%3Crect width='100' height='100' rx='20' fill='url(%23g)'/%3E%3Ctext x='50' y='65' font-size='50' text-anchor='middle' fill='white' font-family='Arial' font-weight='bold'%3EFM%3C/text%3E%3C/svg%3E">
    <style>
        .suporte-container {
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 40px 20px;
        }

        .suporte-box {
            background: var(--bg-card);
            backdrop-filter: blur(20px);
            border: 1px solid var(--border-color);
            border-radius: var(--radius-xl);
            padding: 50px 40px;
            width: 100%;
            max-width: 650px;
            box-shadow: var(--shadow-lg);
        }

        .suporte-header {
            text-align: center;
            margin-bottom: 40px;
        }

        .suporte-logo {
            width: 80px;
            height: 80px;
            background: var(--fm-gradient-primary);
            border-radius: var(--radius-lg);
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 2.5rem;
            margin: 0 auto 20px;
            box-shadow: var(--shadow-glow-primary);
            color: white;
        }

        .suporte-title {
            font-size: 2rem;
            font-weight: 800;
            margin-bottom: 8px;
            background: var(--fm-gradient-hero);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }

        .suporte-subtitle {
            color: var(--text-secondary);
            font-size: 1rem;
        }

        .suporte-content {
            text-align: center;
        }

        .suporte-icon-large {
            width: 100px;
            height: 100px;
            background: rgba(16, 185, 129, 0.1);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 24px;
            font-size: 2.5rem;
            color: var(--fm-primary);
        }

        /* Botões de Contato */
        .contact-buttons {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 16px;
            margin: 30px 0;
        }

        .contact-btn {
            display: flex;
            flex-direction: column;
            align-items: center;
            gap: 12px;
            padding: 28px 20px;
            border-radius: var(--radius-lg);
            text-decoration: none;
            transition: all 0.3s ease;
            border: 2px solid transparent;
        }

        .contact-btn i {
            font-size: 2.5rem;
        }

        .contact-btn span {
            font-weight: 600;
            font-size: 1rem;
        }

        .contact-btn small {
            font-size: 0.8rem;
            opacity: 0.8;
        }

        /* Botão de E-mail */
        .contact-btn.email {
            background: linear-gradient(135deg, rgba(59, 130, 246, 0.15), rgba(59, 130, 246, 0.05));
            border-color: rgba(59, 130, 246, 0.3);
            color: #60a5fa;
        }

        .contact-btn.email:hover {
            background: linear-gradient(135deg, #3b82f6, #2563eb);
            color: white;
            transform: translateY(-4px);
            box-shadow: 0 10px 30px rgba(59, 130, 246, 0.4);
        }

        /* Botão de WhatsApp */
        .contact-btn.whatsapp {
            background: linear-gradient(135deg, rgba(37, 211, 102, 0.15), rgba(37, 211, 102, 0.05));
            border-color: rgba(37, 211, 102, 0.3);
            color: #25d366;
        }

        .contact-btn.whatsapp:hover {
            background: linear-gradient(135deg, #25d366, #128c7e);
            color: white;
            transform: translateY(-4px);
            box-shadow: 0 10px 30px rgba(37, 211, 102, 0.4);
        }

        .contact-btn.disabled {
            opacity: 0.5;
            cursor: not-allowed;
            pointer-events: none;
        }

        .suporte-info {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(180px, 1fr));
            gap: 16px;
            margin-top: 30px;
        }

        .suporte-info-item {
            background: var(--bg-glass);
            border: 1px solid var(--border-color);
            border-radius: var(--radius-md);
            padding: 20px;
            text-align: center;
        }

        .suporte-info-item i {
            font-size: 1.8rem;
            color: var(--fm-primary);
            margin-bottom: 10px;
        }

        .suporte-info-item h4 {
            font-size: 0.95rem;
            margin-bottom: 4px;
        }

        .suporte-info-item p {
            font-size: 0.8rem;
            color: var(--text-muted);
        }

        .suporte-faq {
            margin-top: 40px;
            text-align: left;
        }

        .suporte-faq h3 {
            margin-bottom: 20px;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .suporte-faq h3 i {
            color: var(--fm-primary);
        }

        .faq-item {
            background: var(--bg-glass);
            border: 1px solid var(--border-color);
            border-radius: var(--radius-md);
            margin-bottom: 12px;
            overflow: hidden;
        }

        .faq-question {
            padding: 16px 20px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            cursor: pointer;
            font-weight: 600;
            transition: var(--transition-fast);
        }

        .faq-question:hover {
            background: var(--bg-glass-light);
        }

        .faq-answer {
            padding: 0 20px 16px;
            color: var(--text-secondary);
            font-size: 0.9rem;
            line-height: 1.6;
            display: none;
        }

        .faq-item.active .faq-answer {
            display: block;
        }

        .faq-item.active .faq-question i {
            transform: rotate(180deg);
        }

        .suporte-footer {
            text-align: center;
            margin-top: 40px;
            padding-top: 24px;
            border-top: 1px solid var(--border-color);
        }

        .suporte-footer a {
            color: var(--text-muted);
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            padding: 10px 20px;
            border: 1px solid var(--border-color);
            border-radius: var(--radius-md);
            transition: var(--transition-fast);
        }

        .suporte-footer a:hover {
            background: var(--bg-glass-light);
            border-color: var(--fm-primary);
            color: var(--fm-primary);
        }

        /* Admin Config Box */
        .admin-config {
            background: rgba(245, 158, 11, 0.1);
            border: 1px solid rgba(245, 158, 11, 0.3);
            border-radius: var(--radius-md);
            padding: 20px;
            margin-top: 30px;
            text-align: left;
        }

        .admin-config h4 {
            color: #f59e0b;
            margin-bottom: 12px;
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .admin-config .form-control {
            margin-bottom: 12px;
        }

        .alert-success {
            background: var(--success-light);
            border: 1px solid rgba(16, 185, 129, 0.3);
            color: var(--success);
            padding: 12px 16px;
            border-radius: var(--radius-md);
            margin-bottom: 16px;
        }

        @media (max-width: 480px) {
            .contact-buttons {
                grid-template-columns: 1fr;
            }
        }
    </style>
</head>

<body>
    <div class="suporte-container">
        <div class="suporte-box animate-in">
            <div class="suporte-header">
                <div class="suporte-logo">
                    <i class="fas fa-robot"></i>
                </div>
                <h1 class="suporte-title">Suporte FinnMestre</h1>
                <p class="suporte-subtitle">Estamos aqui para ajudar você!</p>
            </div>

            <div class="suporte-content">
                <div class="suporte-icon-large">
                    <i class="fas fa-headset"></i>
                </div>

                <p style="color: var(--text-secondary); font-size: 1.05rem; line-height: 1.7; margin-bottom: 10px;">
                    Precisa de ajuda? Entre em contato conosco através dos canais abaixo.
                    Nossa equipe responderá o mais breve possível.
                </p>

                <!-- Botões de Contato -->
                <div class="contact-buttons">
                    <!-- Botão E-mail -->
                    <a href="mailto:<?= $emailSuporte ?>" class="contact-btn email">
                        <i class="fas fa-envelope"></i>
                        <span>E-mail</span>
                        <small>
                            <?= $emailSuporte ?>
                        </small>
                    </a>

                    <!-- Botão WhatsApp -->
                    <?php if (!empty($whatsappNumero)): ?>
                        <a href="https://wa.me/<?= $whatsappNumero ?>?text=Olá! Preciso de ajuda com o FinnMestre."
                            target="_blank" class="contact-btn whatsapp">
                            <i class="fab fa-whatsapp"></i>
                            <span>WhatsApp</span>
                            <small>Clique para conversar</small>
                        </a>
                    <?php else: ?>
                        <div class="contact-btn whatsapp disabled">
                            <i class="fab fa-whatsapp"></i>
                            <span>WhatsApp</span>
                            <small>Em breve</small>
                        </div>
                    <?php endif; ?>
                </div>

                <div class="suporte-info">
                    <div class="suporte-info-item">
                        <i class="fas fa-clock"></i>
                        <h4>Horário</h4>
                        <p>Atendimento<br>24 horas</p>
                    </div>
                    <div class="suporte-info-item">
                        <i class="fas fa-bolt"></i>
                        <h4>Resposta</h4>
                        <p>Até 24h úteis</p>
                    </div>
                    <div class="suporte-info-item">
                        <i class="fas fa-shield-alt"></i>
                        <h4>Seguro</h4>
                        <p>Dados protegidos</p>
                    </div>
                </div>
            </div>

            <!-- Configuração Admin (só aparece para admin) -->
            <?php if ($isAdmin): ?>
                <div class="admin-config">
                    <h4><i class="fas fa-cog"></i> Configuração de Admin</h4>

                    <?php if (isset($mensagemSucesso)): ?>
                        <div class="alert-success">
                            <i class="fas fa-check"></i>
                            <?= $mensagemSucesso ?>
                        </div>
                    <?php endif; ?>

                    <form method="POST">
                        <label style="display: block; margin-bottom: 8px; color: var(--text-secondary); font-size: 0.9rem;">
                            Número do WhatsApp (com código do país, ex: 5511999999999)
                        </label>
                        <input type="text" name="whatsapp_numero" class="form-control"
                            value="<?= htmlspecialchars($whatsappNumero) ?>" placeholder="Ex: 5511999999999">
                        <button type="submit" class="btn btn-primary btn-sm">
                            <i class="fas fa-save"></i> Salvar Número
                        </button>
                    </form>
                </div>
            <?php endif; ?>

            <div class="suporte-faq">
                <h3><i class="fas fa-question-circle"></i> Perguntas Frequentes</h3>

                <div class="faq-item">
                    <div class="faq-question" onclick="toggleFaq(this)">
                        Como crio uma conta?
                        <i class="fas fa-chevron-down"></i>
                    </div>
                    <div class="faq-answer">
                        Clique em "Criar conta" na página de login, preencha seus dados (nome, e-mail e senha)
                        e pronto! Sua conta será criada instantaneamente.
                    </div>
                </div>

                <div class="faq-item">
                    <div class="faq-question" onclick="toggleFaq(this)">
                        Esqueci minha senha, o que fazer?
                        <i class="fas fa-chevron-down"></i>
                    </div>
                    <div class="faq-answer">
                        Entre em contato com nosso suporte pelo e-mail
                        <?= $emailSuporte ?> informando o e-mail da sua conta. Enviaremos instruções para redefinir sua
                        senha.
                    </div>
                </div>

                <div class="faq-item">
                    <div class="faq-question" onclick="toggleFaq(this)">
                        Como funciona o FinnMestre?
                        <i class="fas fa-chevron-down"></i>
                    </div>
                    <div class="faq-answer">
                        O FinnMestre é um sistema completo de controle financeiro pessoal. Você pode gerenciar suas
                        contas,
                        acompanhar transações, definir metas e gerar relatórios detalhados.
                    </div>
                </div>

                <div class="faq-item">
                    <div class="faq-question" onclick="toggleFaq(this)">
                        Meus dados estão seguros?
                        <i class="fas fa-chevron-down"></i>
                    </div>
                    <div class="faq-answer">
                        Sim! Utilizamos criptografia de ponta para proteger suas informações. Suas senhas são
                        armazenadas de forma segura e nunca são expostas.
                    </div>
                </div>
            </div>

            <div class="suporte-footer">
                <a href="login.php">
                    <i class="fas fa-arrow-left"></i>
                    Voltar para o Login
                </a>
            </div>
        </div>
    </div>

    <script>
        function toggleFaq(element) {
            const item = element.parentElement;
            item.classList.toggle('active');
        }
    </script>
</body>

</html>